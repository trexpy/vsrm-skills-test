# Şablon kataloğu

Tüm şablonlar tek dosyalık HTML'dir ve internet ya da kurulum gerektirmez. Veriler kurgusaldır.

## Nasıl uyarlanır?

Örnek verinin bir kısmı dosyada yazılı değildir, kod çalışınca üretilir. Bu yüzden tek tek hücre düzeltmeye çalışma:

1. Aşağıdaki **toplu değişim** tablosundaki değerleri dosyanın tamamında değiştir. Tırnak içindeki değer ve kod içindeki kalıp birlikte değişmelidir.
2. Kod çalışınca üretilen değerleri kontrol et: Sayfa açıldıktan sonra `qualityApp.getData()` çıktısına bak. `QualityWorkflow.seed()` yalnızca temel veriyi verir, açılışta eklenen senaryoları içermez.
3. Kod ve sınıf adlarına, kalite süreç adlarına ve statülere dokunma.

Bir değeri kısmen değiştirirsen kayıtlar arası bağlantı kopar. Özellikle ürün, sipariş ve tedarikçi kodları her yerde aynı biçimde değişmelidir.

## asn-kalite

- **Dosya:** `asn-kalite-sablonu.html`
- **Profil:** `classic-v5`
- **Açılış:** Sevkiyat Hazırlık ve Onay
- **Referans:** `kurallar/referans/asn-sevkiyat-izgarasi.png`, `asn-seri-lot-penceresi.png`, `asn-uygunluk-matrisi.png`
- **Ne gösterir:** Sevkiyat ızgarası, seri/lot kalite penceresi, paketleme, kalite belgeleri (GIF, KM, SÖDK, HOLD, SDR, NC, FAI, PPAP, TSPS), uygunluk matrisi, bakım tabloları.

**Toplu değişim:**

| Değer | Şablonda | Not |
|---|---|---|
| Ana firma kodu | `90010` | Tek değer |
| Üretim yeri | `9001` | Tırnak içinde arayın |
| Tedarikçi | `700101`, `700102`, `700190`–`700194` | Formda iki ad verilir. Kalanlar `Örnek Tedarikçi 3` gibi nötr ad alır, silinmez; senaryolar onlara bağlıdır. Seçim listesi kod ve adı birlikte gösterir. |
| Ürün | `77K…R01R`, `77R…`, `D70X-…`, `D80T48R0…`, `GIFBAKIYE…` | Ürün tanımlarının bir kısmı senaryo adıdır ve kodla üretilir. Paketleme örnekleri `specs` listesindedir. |
| Sipariş | `47…` | Boşsa kurgusal kod üret |
| Seri, lot | `ABC`, `DEF`, `SRL`, `KML`, `LOT`, `REQ`, `MIX`, `DS`, `DT`, `DL`, `MRQ`, `MMX`, `MLT` | Yalnızca istenirse değiştir |
| Heat lot | `DH…`, `HT…` | |

`DEMO` kod içinde örnek üretiminde geçer ve açılışta ana firma koduna çevrilir. Ekranda görünmez, değiştirmesen de olur.

**Metin:** `vendorName`, `footerTableP`, `<title>`.

**Marka rengi:** Formdaki ana renk `#menuBar` zeminine ve seçili sekmeye uygulanır. Yazı, tablo ve durum renkleri değişmez.

**Tarayıcı kayıt anahtarı:** `storageKey=` ve `prefsKey=` değerlerine müşteri kısa adını ekle.

**Eksik belge senaryosu:** Yeni kural yazma. İlgili SÖDK belgesini örnek veriden çıkar; ekran satırı kendisi engeller. Başka belge türlerinde sonuç kurala bağlıdır, gösterim öncesi denemeden söz verme.

**Sevk kuralı:** `Kapalı` NC, HOLD ve SDR başlığı sevki kendisi engellemez, satır kararı belirler. `Kapalı` GIF başlığı engeldir ve GIF özel izni uygulanmaz; Kapalı GIF'li satır diğer kontroller uygun olsa da sevk edilemez.

**Not:** Kalite süreçleri ve sevk kuralları örnektir; bu paketin uyarlama sınırı dışındadır. Hazırlanan ekranı müşteriye göstermeden önce süreç sahibi sevk uygunluğu kararlarını onaylamalıdır.

## seri-lot-bakim

- **Dosya:** `seri-lot-bakim-sablonu.html`
- **Profil:** `classic-v5`
- **Referans:** `kurallar/referans/seri-lot-bakim.png`
- **Ne gösterir:** Seri, lot ve miktar ana verisi; arama filtreleri, liste, kayıt detayı.
- **Veri:** `const initial=[` dizisi. Ana firma burada `DEMO`, üretim yeri `9001`.
- **Metin:** `<title>`, `class="kapsam"` bloğu.
- **Tarayıcı kaydı:** Yok.

## mm-fason

- **Dosya:** `mm-fason-sablonu.html`
- **Profil:** `classic-v5`
- **Referans:** `kurallar/referans/mm-fason.png`
- **Ne gösterir:** MM fason süreci; ana firma ve tedarikçi görünümü, satınalma emirleri, üretim beyanı, stok, sevkiyat.
- **Veri:** `function seed(` işlevi ve `700201 · Örnek Fason A.Ş.` metni. Ana firma burada `DEMO`.
- **Metin:** `<title>`, `document.title=`, üst başlık alanı.
- **Tarayıcı kayıt anahtarı:** `vsrm-demo-mm-fason-sim-v2`.

﻿# vSRM test planini kolon adiyla okur. Dosyayi degistirmez.
param(
    [Parameter(Mandatory = $true)][string]$Plan,
    [string]$Sayfa = 'Test Takip',
    [string]$Blok,
    [string]$No,
    [switch]$Bekleyen
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
if (-not (Test-Path -LiteralPath $Plan)) { throw "Dosya yok: $Plan" }
$noList = @(); if ($No) { $noList = $No -split '[,\s]+' | Where-Object { $_ } }
$xl = New-Object -ComObject Excel.Application
$xl.Visible = $false; $xl.DisplayAlerts = $false
try {
    $wb = $xl.Workbooks.Open($Plan, 0, $true)
    $ws = $wb.Worksheets.Item($Sayfa)
    $v = $ws.UsedRange.Value2
    $satir = $v.GetLength(0); $kolon = $v.GetLength(1)
    $ad = @{}
    for ($c = 1; $c -le $kolon; $c++) { $ad[[string]$v[1, $c]] = $c }
    $adet = 0
    for ($r = 2; $r -le $satir; $r++) {
        $ilk = [string]$v[$r, 1]
        if (-not $ilk) { continue }
        if ($Sayfa -eq 'Test Takip') {
            if ($Blok -and [string]$v[$r, $ad['Blok']] -ne $Blok) { continue }
            if ($noList.Count -and $noList -notcontains $ilk) { continue }
            if ($Bekleyen -and [string]$v[$r, $ad['Sonuç']]) { continue }
        }
        $parca = @()
        for ($c = 1; $c -le $kolon; $c++) {
            $x = [string]$v[$r, $c]
            if ($x) { $parca += ([string]$v[1, $c]) + '=' + ($x -replace '[\r\n]+', ' / ') }
        }
        "R$r | " + ($parca -join ' | ')
        $adet++
    }
    "Satir: $adet"
    $wb.Close($false)
} finally {
    $xl.Quit()
    [void][Runtime.InteropServices.Marshal]::ReleaseComObject($xl)
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()
}

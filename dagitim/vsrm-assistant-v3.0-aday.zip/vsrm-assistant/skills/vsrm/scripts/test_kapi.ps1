﻿# Canli ortam kilidi. Izinli adresler yalniz bu dosyadadir; plan dosyasi listeyi genisletemez.
param([Parameter(Mandatory = $true)][string]$Adres)
$ErrorActionPreference = 'Stop'
$izinli = @('test.vsrm.net')
$uri = $null
if (-not [uri]::TryCreate($Adres, [UriKind]::Absolute, [ref]$uri)) { throw "Gecersiz adres: $Adres" }
if ($uri.Scheme -ne 'https' -or $izinli -notcontains $uri.Host.ToLowerInvariant()) {
    throw "Bu adreste test calistirilamaz: $($uri.Host). Yalniz test ortami acik; canli ortam kapali."
}
"Izinli: $($uri.Host)"

﻿# Bir adimin sonucunu plana yazar. Sonuc yalniz izinli test adresinden gelen kanitla yazilabilir.
param(
    [Parameter(Mandatory = $true)][string]$Plan,
    [Parameter(Mandatory = $true)][string]$No,
    [Parameter(Mandatory = $true)][string]$Sonuc,
    [Parameter(Mandatory = $true)][string]$Adres,
    [string]$TestVerisi,
    [string]$TestEden,
    [string]$Tarih = (Get-Date -Format 'dd.MM.yyyy'),
    [string]$Bulgu,
    [string]$Aciklama,
    [string]$GercekJsp,
    [switch]$Uzerine
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
& (Join-Path $PSScriptRoot 'test_kapi.ps1') -Adres $Adres | Out-Null
$izin = 'Tam', 'Kısmi', 'Yapılmamış', 'Veri hatalı', 'Karar bekliyor', 'Test edilemedi'
if ($izin -cnotcontains $Sonuc) { throw "Gecersiz sonuc: $Sonuc. Izinli: $($izin -join ', ')" }
if (-not (Test-Path -LiteralPath $Plan)) { throw "Dosya yok: $Plan" }
$xl = New-Object -ComObject Excel.Application
$xl.Visible = $false; $xl.DisplayAlerts = $false
try {
    $wb = $xl.Workbooks.Open($Plan, 0, $false)
    if ($wb.ReadOnly) { $wb.Close($false); throw "Dosya baska yerde acik, yazilamadi. Excel'de kapatilmali: $Plan" }
    $ws = $wb.Worksheets.Item('Test Takip')
    $v = $ws.UsedRange.Value2
    $ad = @{}
    for ($c = 1; $c -le $v.GetLength(1); $c++) { $ad[[string]$v[1, $c]] = $c }
    foreach ($gerekli in 'No', 'Sonuç', 'Tarih') { if (-not $ad.ContainsKey($gerekli)) { throw "Kolon yok: $gerekli" } }
    $r = 0
    for ($i = 2; $i -le $v.GetLength(0); $i++) { if ([string]$v[$i, $ad['No']] -ceq $No) { $r = $i; break } }
    if (-not $r) { throw "Adim bulunamadi: $No" }
    $eski = [string]$v[$r, $ad['Sonuç']]
    if ($eski -and -not $Uzerine) { throw "Adim $No zaten dolu ($eski). Degistirmek icin -Uzerine kullan." }
    $yaz = @{ 'Sonuç' = $Sonuc; 'Tarih' = $Tarih }
    if ($PSBoundParameters.ContainsKey('TestVerisi')) { $yaz['Test verisi'] = $TestVerisi }
    if ($PSBoundParameters.ContainsKey('TestEden')) { $yaz['Test eden'] = $TestEden }
    if ($PSBoundParameters.ContainsKey('Bulgu')) { $yaz['Bulgu'] = $Bulgu }
    if ($PSBoundParameters.ContainsKey('Aciklama')) { $yaz['Açıklama'] = $Aciklama }
    if ($PSBoundParameters.ContainsKey('GercekJsp')) { $yaz['JSP'] = $GercekJsp }
    foreach ($k in $yaz.Keys) {
        if (-not $ad.ContainsKey($k)) { throw "Kolon yok: $k" }
        $hucre = $ws.Cells.Item($r, $ad[$k])
        $hucre.NumberFormat = '@'
        $hucre.Value2 = $yaz[$k]
    }
    $wb.Save()
    "Adim $No R$r | Sonuc=$($ws.Cells.Item($r, $ad['Sonuç']).Value2) | Tarih=$($ws.Cells.Item($r, $ad['Tarih']).Value2)"
    $wb.Close($false)
} finally {
    $xl.Quit()
    [void][Runtime.InteropServices.Marshal]::ReleaseComObject($xl)
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()
}

﻿# Bos vSRM test plani uretir. Var olan dosyanin uzerine yazmaz; dosya sonuc tasiyor olabilir.
param([Parameter(Mandatory = $true)][string]$Cikti)
$ErrorActionPreference = 'Stop'
if (Test-Path -LiteralPath $Cikti) { throw "Dosya zaten var: $Cikti" }
$kolonlar = 'No', 'Blok', 'Adım', 'Rol', 'Ekran', 'JSP', 'Ön koşul', 'Beklenen sonuç', 'Yazma', 'Test verisi', 'Sonuç', 'Test eden', 'Tarih', 'Bulgu', 'Açıklama'
$sonuclar = 'Tam,Kısmi,Yapılmamış,Veri hatalı,Karar bekliyor,Test edilemedi'
function Baslik($Sayfa, [string[]]$Adlar) {
    for ($i = 0; $i -lt $Adlar.Count; $i++) { $Sayfa.Cells.Item(1, $i + 1).Value2 = $Adlar[$i] }
    $Sayfa.Rows.Item(1).Font.Bold = $true
    $Sayfa.Columns.AutoFit() | Out-Null
}
$xl = New-Object -ComObject Excel.Application
$xl.Visible = $false; $xl.DisplayAlerts = $false
try {
    $wb = $xl.Workbooks.Add()
    while ($wb.Worksheets.Count -lt 3) { [void]$wb.Worksheets.Add() }
    while ($wb.Worksheets.Count -gt 3) { $wb.Worksheets.Item($wb.Worksheets.Count).Delete() }
    $takip = $wb.Worksheets.Item(1); $takip.Name = 'Test Takip'; Baslik $takip $kolonlar
    $bloklar = $wb.Worksheets.Item(2); $bloklar.Name = 'Bloklar'; Baslik $bloklar @('Blok', 'Ad', 'Bağlı olduğu')
    $konular = $wb.Worksheets.Item(3); $konular.Name = 'Açık Konular'; Baslik $konular @('Konu', 'Etkilenen adım', 'Karar', 'Sorumlu')
    $sonucKolon = [array]::IndexOf($kolonlar, 'Sonuç') + 1
    $alan = $takip.Range($takip.Cells.Item(2, $sonucKolon), $takip.Cells.Item(2000, $sonucKolon))
    [void]$alan.Validation.Add(3, 1, 1, $sonuclar)
    $yazmaKolon = [array]::IndexOf($kolonlar, 'Yazma') + 1
    $alan2 = $takip.Range($takip.Cells.Item(2, $yazmaKolon), $takip.Cells.Item(2000, $yazmaKolon))
    [void]$alan2.Validation.Add(3, 1, 1, 'Evet,Hayır')
    New-Item -ItemType Directory -Force (Split-Path -Parent $Cikti) | Out-Null
    $wb.SaveAs($Cikti, 51)
    $wb.Close($false)
    "Plan hazir: $Cikti"
} finally {
    $xl.Quit()
    [void][Runtime.InteropServices.Marshal]::ReleaseComObject($xl)
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()
}

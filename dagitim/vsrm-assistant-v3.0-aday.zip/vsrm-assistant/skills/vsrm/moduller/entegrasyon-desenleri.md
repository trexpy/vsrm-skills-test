# Entegrasyon desenleri

Menü: **Bilgi → Entegrasyon desenleri** (`Format_Katalogu.html`). Format arama, inceleme, alan review, proje sürümü sabitleme, Excel indirme, tablo kopyalama.

- Boş zorunluluk hücresini isteğe bağlı sayma.
- Aynı adlı farklı sürümleri karıştırma; müşteri ve sürüm netleşmeden alan eşlemesini kesinleştirme.
- **Yalnız doğrulanmış sürümler** süzgecini kullan. Doğrulanmamış desen Kararlar ekranının Genel sekmesine düşer.
- Proje için kullanılan sürümü **Proje sürümünü sabitle** ile kilitle.
- Dış standart kaynakları ürünün o standardı desteklediğini kanıtlamaz.

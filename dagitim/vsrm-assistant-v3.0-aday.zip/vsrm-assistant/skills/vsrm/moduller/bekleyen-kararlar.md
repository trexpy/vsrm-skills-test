# Bekleyen kararlar

Menü: **Projeler → Kararlar** (`Bekleyen_Kararlar.html`). Sekmeler: Proje, Genel, Kapanan. Kayıt sağdaki formdan **Karar kaydet** ile güncellenir. Toplantı açık soruları, eksik aksiyon bilgileri, tasarım kararları, desen incelemeleri ve iş eksikleri tek listede toplanır.

- Kaydı güncelle formu: müşteri, proje, modül, sorumlu, durum, hedef tarih, öneri, kapanış kanıtı.
- Durumlar: Açık, Bilgi bekliyor, İncelemede, Kapandı.
- Kapatırken kanıt zorunludur. Kim, ne zaman, hangi dayanakla karar verdi yaz.
- Kararın sahibi danışman değilse karar verme; öneri yaz ve sahibini belirt.
- Finalize kontrol açık kayıtları engelleyici sayar.

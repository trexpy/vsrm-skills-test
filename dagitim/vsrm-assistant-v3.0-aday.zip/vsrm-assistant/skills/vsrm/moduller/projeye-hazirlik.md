# Projeye hazırlık

Menü: **Projeler → Hazırlık** (`Projeye_Hazirlik.html`). Müşteri, proje ve süreç seçilir; görevler tamamlanır, not ve kanıt yazılır.

- Bilgi eksikse **Bilgi bekleniyor** işaretle. Kayıt Bugün ekranında görünür.
- Adım çıktısı panoya aktarılarak iş haline getirilebilir.
- Şablondaki kişi, tarih ve bütçeleri gerçek proje bilgisi olarak sunma.
- Yeni müşteride önce kapsam, rol ve ortam (sürüm) bilgisini netleştir.

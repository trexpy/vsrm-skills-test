# Proje takibi

Menü: **Projeler → Task'lar** (`Proje_Takip.html`). Yerel ve Jira işleri tek tabloda. Sekmeler: İşler, Sprint ve plan, Riskler. Araçlar: Filtreler, Veri aktar, Durum özeti, Yeni iş. Satıra tıklayınca sağda düzenleme paneli açılır; **Task metnini yaz** ve **Developer'a anlat** oradadır.

## Durum sorusu geldiğinde

1. Müşteri ve projeyi netleştir.
2. Veri kaynağını ve tarihini söyle. Jira verisi anlık kopyadır, canlı değildir. Güncel durum için danışmandan Jira CSV'si iste ve **Veri aktar** ile yüklet.
3. Şu sırayla özetle: geciken işler, sorumlusu olmayanlar, bağımlılığı bekleyenler, sprint riski.
4. Plan veya kapasite verisi eksikse bunu uyum sorunu sayma, "plan bilgisi yok" de.

## İş durumları

Taslak, Planlandı, Devam ediyor, Bekliyor, Tamamlandı, Plan Dışı.

## Sınırlar

- Jira işleri ile yerel işler ayrı listelerdir. Aralarındaki bağ elle girilen Jira numarasıdır.
- Uygulama Jira'ya yazmaz.
- Profil seçimi görünüm filtresidir, yetkilendirme değildir.
- Müşteri aksiyonları `Musteri_Yapilacaklar.csv` olarak alınabilir.

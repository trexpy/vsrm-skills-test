# Toplantı notları

Menü: **Projeler → Toplantılar** (`Toplanti_Notlari.html`). Sekmeler: Aksiyonlar, Not, Konuşmalar, Kayıt.

## Akış

1. **Yeni toplantı** aç. Başlık, tarih, müşteri, proje ve not biçimini gir.
2. **Kaydı başlat** veya **Sesi yazıya dök**. Metin hazırsa yapıştır.
3. Konuşmacıları düzelt. Konuşmacı ayrımı anonim gruplar üretir; isim eşlemesi danışmanındır.
4. Üstteki **Toplantı notu çıkar**, not varsa Not sekmesindeki **AI ile toplantı notu oluştur**. Yapay zekâ bağlantısı yoksa **Konu etiketlerinden boş not oluştur** ile elle ilerle.
5. Konu başına Beyan, Karar, Öneri, Aksiyon ve açık soruları gözden geçir.
6. Üstteki **Task çıkar** ile yapay zekâdan taslak al, kartları **Onayla** veya **Düzelt**. Tek aksiyon için Aksiyonlar sekmesinde **Task'a aktar**.
7. DOCX, TXT, VTT, JSON veya medyalı ZIP olarak dışa aktar.

## Not yazarken

- Beyan, karar ve öneriyi karıştırma. Söylenen şey karar değilse karar yazma.
- Aksiyonda iş, sorumlu, taraf ve termin ayrı alanlardır. Söylenmediyse boş bırak; uygulama bunu Kararlar ekranı'a taşır.
- Her ifadeyi kaynağındaki konuşma parçasına bağla.
- Açık soruyu sessizce cevaplama.
- Müşteriye gidecek notta iç yorumları çıkar ve danışmana son okumayı yaptır.

## Sonraki adım

Aksiyonlar için [../akislar/gorev-acma.md](../akislar/gorev-acma.md). Açık sorular için [bekleyen-kararlar.md](bekleyen-kararlar.md).

# Süreç rehberi

Menü: **Bilgi → Süreç rehberi** (`Tum_Surecler_Asistani.html`). Süreç adımları, kaynaklar, **Bu adımı açıkla** ve sohbet.

Süreç sorusuna şu sırayla cevap ver: sonuç, ön koşul, işlem, beklenen çıktı, kaynak. Müşteri, rol, modül, ortam ve sürüm belirsizse netleştir. Ana firma ve tedarikçi rollerini varsayma. Menü sırası zorunlu işlem sırası değildir.

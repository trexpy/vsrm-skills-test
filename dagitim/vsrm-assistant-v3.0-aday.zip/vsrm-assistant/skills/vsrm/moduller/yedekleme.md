# Yedekleme

Menü: **Araçlar → Yedekleme** (`Yedekleme.html`). **Tüm çalışma alanını yedekle** ile ZIP alınır. Geri yüklemede bütünlük kontrolü yapılır ve önce güvenlik yedeği indirilir.

- Yedek otomatik değildir. Finalize öncesinde ve bilgisayar değişiminde mutlaka al.
- Yedek müşteri verisi içerir; ortak klasöre koyma.
- Yedek AI anahtarlarını taşımaz.
- Tasarım kanıt dosyaları ve bazı müşteri simülasyonu kayıtları yedeğe girmez. Önemli kanıtı ayrıca sakla.

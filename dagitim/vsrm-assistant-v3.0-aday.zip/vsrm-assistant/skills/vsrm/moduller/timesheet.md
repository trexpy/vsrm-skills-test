# Timesheet

Menü: **Araçlar → Timesheet** (`Timesheet.html`). **AI ile düzenle** dağınık notları düzene sokar; sonuç uygulanmadan notlar değişmez. Üç adım: Notları al → Kayıtları düzenle → Önizle ve indir. Çıktı `activity_list_*.xlsx`.

- Süre dakika, tarih `gg.aa.yyyy` biçiminde gerçek Excel tarihidir.
- Açıklamaya saat aralığı yazma.
- Çalışma oturumları öneri getirir, onay danışmanındır.
- Jira'ya çalışma süresi yazılmaz.

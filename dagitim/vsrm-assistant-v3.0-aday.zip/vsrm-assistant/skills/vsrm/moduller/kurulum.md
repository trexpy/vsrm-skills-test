# Kurulum ve ekleme

Danışman yeni komut veya ağır parça eklemek ister ya da güncelleme sorarsa bu adımları izle. Betik `%USERPROFILE%\.vsrm-assistant\paket\vsrm-assistant\kurulum\baslat.ps1` yolundadır. "Güncelle" istenirse `-Komut` ve `-Bilesen` vermeden çalıştır; yeni komut varsa `-Liste` çıktısından söyle.

1. Betiği `-Liste` ile çalıştır. Hangi komutların kurulu olduğunu ve parçaların boyutunu göster.
2. Ne eklemek istediğini sor. Toplantı kaydını yazıya dökme (`ses`) büyük bir indirmedir; boyutunu söyle ve şimdi mi sonra mı istediğini sor.
3. Onay al, sonra çalıştır:

   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File "%USERPROFILE%\.vsrm-assistant\paket\vsrm-assistant\kurulum\baslat.ps1" -Komut vsrm-timesheet -Bilesen ses
   ```

4. Uzun indirmeyi arka planda çalıştır, danışman işine devam etsin.
5. Bitince yapay zekâ aracını yeniden başlatmasını söyle.

Seçim eklemelidir: önceki komutlar ve parçalar korunur. Yönetici yetkisi isteme, OneDrive veya güvenlik ayarlarını değiştirme.

`ses` kurulu değilse toplantı notu yine çalışır: danışman metni yapıştırır, kayıt ve otomatik yazıya dökme kullanılamaz.

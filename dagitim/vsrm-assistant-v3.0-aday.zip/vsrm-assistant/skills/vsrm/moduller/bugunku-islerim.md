# Bugünkü işlerim

Menü: **Bugün** (`Bugunku_Islerim.html`). Günün başlangıç ekranı, bütün projeleri üç sütunda gösterir: Şimdi yap, Bekleyen, Toplantılar. Kapsamı yalnız profil seçimi daraltır.

- **İşi aç:** kaydın detayına gider.
- **Çalışmaya başla:** süre tutar, süre Timesheet'e öneri olur.
- **Tamamlandı olarak işaretle:** önce öncül işleri denetler.

"Bugün ne yapmalıyım" sorusunda önce geciken ve bugünkü işleri, sonra bilgi bekleyenleri sırala. Öncelik kararını danışmana bırak.

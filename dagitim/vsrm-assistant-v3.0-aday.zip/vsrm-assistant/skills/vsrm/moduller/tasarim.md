# Tasarım

Menü: **Projeler → Tasarım** (`Tasarim_Sihirbazi.html`). Listede **Task çıkar**, **Developer'a anlat** ve **Claude için kopyala** bulunur. Yedi aşama: Kapsam, İş akışı, Veri ve alanlar, Ekran tasarımı, Roller ve yetkiler, Entegrasyonlar, Kontrol ve çıktılar.

## Hangi yol

- **Danışman müşteriye gösterilecek bir ekran dosyası istiyorsa:** Şablon yolunu izle. Bu komutla gelen `sablonlar/SABLONLAR.md` dosyasından en yakın şablonu seç, kopyasında çalış. Çıktı klasörü: danışmanın çalıştığı klasörde `cikti/`.
- **Danışman Merkezi'nde tasarım kaydı tutuyorsa:** Aşağıdaki akışı izle.

Şablon yolunda önce `musteri-formu.md` kopyasını danışmanla doldur. Müşteri adı bilinmeden kopya üretme.

## Akış

1. Müşteri ve projeyi seç, taslak aç.
2. Aşamaları sırayla tamamla. Bilgi eksikse **Bilgi bekleniyor** işaretle, uydurma.
3. Ekran aşamasında bileşenleri yerleştir, örnek veriyi düzenle, **Önizle**.
4. Her bileşene isteri ve kabul ölçütünü bağla. Bu alanlar developer aktarımının temelidir.
5. Son aşamada **Kontrolü tamamla**.
6. **Geliştirme ve kabul taslaklarını panoya aktar** ile her bileşen için iş oluştur.
7. PNG, PDF, TXT, JSON, v5 HTML veya açık karar raporu al.

## Ekran kuralları

Ekran üretir veya düzenlerken önce [../kurallar/ekran-uretim-rehberi.md](../kurallar/ekran-uretim-rehberi.md), sonra [../kurallar/tasarim-kurallari.md](../kurallar/tasarim-kurallari.md) dosyasını oku. Bileşen dosyası büyüktür, yalnız ilgili bölümü oku.

## Sınırlar

Panoya aktarma son kontrolü şart koşmaz, bu yüzden aktarmadan önce kontrolün bittiğini doğrula. Kararlar ekranında kapatılan karar tasarım taslağına geri yazılmaz; Finalize kontrol ikisini birlikte değerlendirir.

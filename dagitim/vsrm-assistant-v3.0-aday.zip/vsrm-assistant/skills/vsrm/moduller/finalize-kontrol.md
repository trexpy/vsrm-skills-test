# Finalize kontrol

Menü: **Projeler → Finalize** (`Finalize_Kontrol.html`). **Bağımsız denetle** kanıt paketini denetçi talimatıyla ekrandan değerlendirir. Projenin kapanışa hazır olup olmadığını kanıtlarla gösterir. Kayıtları yalnız okur; Jira'ya yazmaz, modele göndermez.

## Danışman nasıl kullanır

1. Üstten müşteri ve projeyi seç.
2. **Kontroller** sekmesinde eksikleri gör, kayda gidip düzelt.
3. **Onaylar** sekmesinde her onaya kanıt yaz. Kanıtsız onay kaydedilmez.
4. Gerçekten geçerli bir sebep varsa **İstisna ver** ile gerekçe yaz.
5. **Kapanış** sekmesinden projeyi kapat veya **Kanıt paketini indir**.
6. **Agent ayarları** ile kontrolleri aç/kapat, otomatik çalışmayı yönet. **Geçmiş** sonuç değişimlerini gösterir.

## Sonuçlar

- **Hazır:** bütün kontroller kanıtla geçti.
- **Koşullu:** engelleyici eksik yok, ama uyarı, istisna veya kapatılmış engelleyici kontrol var. Kapanış için gerekçe gerekir.
- **Hazır değil:** engelleyici kontrol açık veya kanıtı yok. Proje kapatılamaz.

Kanıt yoksa geçti sayılmaz. Kapatılan engelleyici kontrol sonucu en iyi ihtimalle Koşullu yapar. İstisna, bulgu değişince geçersiz olur. Onaylara istisna verilmez; kanıt gerekir.

## Otomatik kontroller

| Kimlik | Kontrol | Tür |
|---|---|---|
| `toplanti-aksiyon-sahibi` | Toplantı aksiyonlarının sorumlusu ve termini belli | Engelleyici |
| `toplanti-aksiyon-gorev` | Toplantı aksiyonları işe dönüştürüldü | Uyarı |
| `toplanti-acik-soru` | Toplantı açık soruları kapandı | Engelleyici |
| `tasarim-kontrol` | Tasarımların son kontrolü tamamlandı | Engelleyici |
| `tasarim-karar` | Tasarım kararları sahipli ve dayanaklı | Engelleyici |
| `tasarim-gorev` | Tasarım bileşenleri geliştirme işine aktarıldı | Engelleyici |
| `gorev-tamam` | Projedeki işler kapandı | Engelleyici |
| `gorev-sahip` | İşlerin sorumlusu ve planı belli | Uyarı |
| `gorev-kabul` | Tasarım işlerinin kabul ölçütü yazıldı | Engelleyici |
| `gorev-test-sonucu` | Tasarım işlerinin kabul testi geçti | Engelleyici |
| `gorev-kaynak-inceleme` | Kaynağı değişen işler yeniden incelendi | Engelleyici |
| `gorev-jira` | İşlerin Jira numarası işlendi | Uyarı |
| `karar-acik` | Bekleyen kararlar kapandı | Engelleyici |
| `hazirlik-bekleyen` | Hazırlık adımlarında bekleyen bilgi yok | Uyarı |

## Elle onaylar

| Kimlik | Onay | Tür |
|---|---|---|
| `onay-test` | Test / UAT sonuçları onaylandı | Engelleyici |
| `onay-surec` | İş kuralları süreç sahibi tarafından onaylandı | Engelleyici |
| `onay-musteri` | Müşteri kabulü alındı | Engelleyici |
| `devir-dokuman` | Doküman ve destek devri tamamlandı | Engelleyici |
| `devir-yedek` | Çalışma alanı yedeği alındı | Uyarı |

## Agent ile bağımsız denetim

Danışman `finalize-kanit.json` dosyasını verdiğinde [../agents/finalize-denetci.md](../agents/finalize-denetci.md) talimatını uygula. Mümkünse ayrı bir alt ajanda çalıştır ki danışmanın gerekçeleri denetçiyi yönlendirmesin. Denetçi yalnız raporlar; kapanış kararı danışman ve süreç sahibinindir.

## Sınırlar

Agent yalnız bu tarayıcıdaki yerel kayıtları görür. Jira'daki canlı durumu görmez: `gorev-tamam` yerel iş kayıtlarını değerlendirir. Jira'da kapanmış işi yerel kayıtta da güncelle.

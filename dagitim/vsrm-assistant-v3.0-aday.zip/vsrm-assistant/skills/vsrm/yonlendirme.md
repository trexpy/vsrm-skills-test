## İsteği doğru dosyaya yönlendir

Yalnız işe yarayan dosyayı oku. Hepsini okuma.

| Danışman ne istiyor | Oku |
|---|---|
| Toplantı notu, kayıt, transkript, aksiyon | [moduller/toplanti-notlari.md](moduller/toplanti-notlari.md) |
| Ekran tasarımı, bileşen, tasarım akışı | [moduller/tasarim.md](moduller/tasarim.md) |
| Proje taski açma, Jira'ya hazırlık | [akislar/gorev-acma.md](akislar/gorev-acma.md) |
| Developer'a tasarım aktarımı, task anlatımı | [akislar/developer-aktarimi.md](akislar/developer-aktarimi.md) |
| Ekran görüntülü task rehberi, görselli task dokümanı | [akislar/task-rehberi.md](akislar/task-rehberi.md) |
| Proje durumu, risk, sprint, iş takibi | [moduller/proje-takibi.md](moduller/proje-takibi.md) |
| Proje testi, test planı, test bloğu | [moduller/test.md](moduller/test.md) |
| Proje kapanışa hazır mı, finalize, go-live öncesi kontrol | [moduller/finalize-kontrol.md](moduller/finalize-kontrol.md) |
| Bugün ne yapmalıyım | [moduller/bugunku-islerim.md](moduller/bugunku-islerim.md) |
| Toplantı notundan task çıkarma | [moduller/toplanti-notlari.md](moduller/toplanti-notlari.md) ve [akislar/gorev-acma.md](akislar/gorev-acma.md) |
| Yeni projeye başlama, hazırlık | [moduller/projeye-hazirlik.md](moduller/projeye-hazirlik.md) |
| Entegrasyon deseni, format, alan | [moduller/entegrasyon-desenleri.md](moduller/entegrasyon-desenleri.md) |
| Timesheet, çalışma süresi | [moduller/timesheet.md](moduller/timesheet.md) |
| Süreç, modül nasıl çalışır | [moduller/surec-rehberi.md](moduller/surec-rehberi.md) |
| Belge, kavram, kaynak arama | [moduller/bilgi-merkezi.md](moduller/bilgi-merkezi.md) |
| Açık karar, teyit bekleyen konu | [moduller/bekleyen-kararlar.md](moduller/bekleyen-kararlar.md) |
| Komut veya ağır parça ekleme, güncelleme | [moduller/kurulum.md](moduller/kurulum.md) |
| Yedek alma, başka bilgisayara taşıma | [moduller/yedekleme.md](moduller/yedekleme.md) |

İş birden çok menüye yayılıyorsa danışmanın yaşam döngüsünü izle:

Hazırlık → Toplantı → Tasarım → Task → Developer aktarımı → Takip → Kararlar → Finalize

# Proje taski açma

Uygulama şimdilik Jira'ya yazmaz. İş önce yerelde taslak olarak açılır, Jira kaydını danışman elle girer, numarayı yerel işe yazar.

## İşin geldiği yerler

| Kaynak | Yol |
|---|---|
| Toplantı aksiyonu | Projeler → Toplantılar → Task çıkar veya Task'a aktar |
| Tasarım bileşeni | Tasarım → Geliştirme ve kabul taslaklarını panoya aktar |
| Hazırlık adımı | Projeler → Hazırlık → panoya aktar |
| Doğrudan | Projeler → Task'lar → Yeni iş |

## İyi bir task

Tek bir sonucu anlatır, tek sorumlusu olur, kapandığı nasıl anlaşılır yazar. Şu kalıbı kullan:

```
Başlık: <Modül veya konu> - <ad haline gelmiş iş>
İş türü:
Öncelik:
Müşteri / proje:
Yapacak taraf: ITG / Müşteri / Tedarikçi
Sorumlu: (söylenmediyse "teyit bekliyor")
Plan tarihi / termin:
Bağımlılık:
Neden: 1-2 cümle iş ihtiyacı
Kapsam: yapılacaklar
Kapsam dışı:
Kabul ölçütü: ölçülebilir madde madde; toplantıda geçmediyse "Öneri (teyit bekliyor):" ile yaz
Test senaryosu: adım → beklenen sonuç
Kaynak: toplantı / tasarım / karar referansı
```

## Adımlar

1. Taslağı üret, eksik alanları "teyit bekliyor" bırak.
2. Danışman Task'lar ekranında satıra tıklayıp sorumlu ve tarihi girer.
3. Danışman Jira'da açar, numarayı **Jira işi** alanına yazar.
4. Tasarımdan gelen işlerde sonraki adım [developer-aktarimi.md](developer-aktarimi.md).

İş türü, başlık ve öncelik için [jira-kaliplari.md](jira-kaliplari.md) dosyasına bak.

## Karar mı, task mı

- Bir şeyin kararı bekleniyorsa **bekleyen karar** yaz, task açma. Sorumlu ve termin karar kaydında durur.
- Karar çıktıktan sonra yapılacak bir iş varsa o iş task olur ve karara bağımlı yazılır.
- Müşteri tarafının işi için "Yapacak taraf: Müşteri" yaz. Jira'ya girip girmeyeceğini danışman seçer.

## Mükerrer iş

Birleşik işi böl. Aynı işi iki kaynaktan iki kez açma. Önce Task'lar ekranında ve danışmanın verdiği listede ara. Erişimin yoksa taslağa "Önce mevcut kayıt aranmalı" yaz ve danışmana sor; "yok" diye varsayma.

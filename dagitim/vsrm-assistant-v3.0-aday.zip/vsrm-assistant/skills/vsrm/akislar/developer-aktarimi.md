# Developer'a tasarım aktarımı ve task anlatımı

Amaç: developer'ın danışmana soru sormadan işe başlayabilmesi. Eksik bilgiyle aktarmak yerine eksiği görünür yaz.

## Önce kontrol et

- Tasarımın son kontrolü tamamlandı mı? Uygulama bunu aktarım sırasında zorunlu kılmaz.
- Her bileşenin isteri ve kabul ölçütü var mı?
- Açık kararlar listelendi mi?

Tasarım veya son kontrol yoksa durma: taslağı yaz, en üste "Kodlamaya hazır değil" ve nedenini ekle.

## Paket

Danışman açıkça paket isterse klasör biçimi için `kurallar/gelistirici-teslimi.md` dosyasını izle. Tasarım ekranından v5 HTML veya PNG, `vsrm-gelistirme-ihtiyaclari.txt`, JSON ve açık karar raporu alınabilir. Tasarım bileşeni varsa her biri için bir iş olmalı; yoksa mevcut Jira işine bağla.

Müşteriye özel eski developer paketlerini kopyalayıp başka müşteriye verme.

## Task anlatımı

Tek görev metni kalıbı budur. Klasör halinde teslim edilecekse aynı içerik `_Jira_Aciklamasi.txt` dosyasına yazılır.

```
İş: <Jira numarası> · <başlık>
Ne yapılacak: 2-3 cümle, iş diliyle
Neden: iş ihtiyacı ve kaynak toplantı/karar
Ekran: bileşen adı ve görsel referans
Alanlar: ad · tip · kaynak · zorunlu mu · düzenlenebilir mi
Davranış: durum akışı, ret ve hata durumları, rol farkları
Entegrasyon: format ve sürüm, yön, tetikleyici
Kabul ölçütü: madde madde
Test senaryosu: adım → beklenen sonuç
Açık kararlar: sorumlusuyla. Karar çıkmadan kodlanmayacak yerleri belirt
Örnek veri uyarısı: ekrandaki veriler örnektir
```

Şunları özellikle ayır: kesin karar, müşteri beyanı, varsayım, örnek süreç. Şablondaki kalite kuralları müşteri onayı olmadan kesin kural değildir.

Son olarak kendine sor: "Developer bu metinle kime soru sormak zorunda kalır?" Cevap varsa eksiği açık karar olarak yaz ve danışmana söyle. Teslim kararı danışmanındır.

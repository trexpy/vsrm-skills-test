# Jira task kalıpları

29.314 Jira kaydının toplu istatistiğinden çıkarıldı (5 Ekim 2026 anlık kopyası). Kayıt, kişi veya müşteri bilgisi içermez. Sayılar eğilimdir, kural değildir.

## İş türü

| Tür | Pay | Ne zaman |
|---|---|---|
| Live System Issue | %31 | Canlı sistemdeki sorun |
| vSRM Development TEST | %27 | Geliştirmenin test işi |
| Improvement | %11 | Mevcut işlevin iyileştirilmesi |
| Task | %9 | Genel iş |
| Change Request | %6 | Kapsam değişikliği talebi |
| Bug | %6 | Hata |
| Development | %3 | Geliştirme işi |
| Test System Issue | %2 | Test sistemindeki sorun |
| Project Task | %1 | Proje işi |

Canlı ve test sistemi sorununu ayır. Türü bilmiyorsan seçme, "teyit bekliyor" yaz.

## Başlık

- Tipik uzunluk 53 karakter, üst sınır olarak 95 karakteri hedefle.
- Başlık çoğunlukla konu ve ad haline gelmiş iş ile biter: "… eklenmesi", "… düzenlemesi", "… geliştirmesi", "… hatası", "… sorunu".
- Varsayılan biçim: `<Modül veya konu> - <ad haline gelmiş iş>`. Projenin yerleşik kalıbı farklıysa onu izle.
- "hk.", "hakkında", "güncelleme" gibi belirsiz kapanışlardan kaçın; ne değiştiğini yaz.

## Öncelik

Kayıtların %79'u Medium. Highest ve High yaklaşık %10'ar. Yüksek öncelik için sebep yaz; danışman kararı olmadan yükseltme.

## Durum akışı

Sık görülen durumlar: Assigned to Task Owner, Analysis / Design Review Queue, Planned, Test Queue, Release Queue, Released, Waiting For Invoice, Invoiced, Closed. Kapanış dışı yollar: OnHold, Waiting for Approval, Cancelled. Bu sıra durum adlarından çıkarıldı; gerçek geçişler Jira erişimiyle doğrulanacak.

## Açıklama

Kayıtların %98'inde açıklama var, tipik uzunluk 344 karakter. Ama yalnız %3'ü kabul ölçütünden, %1'den azı beklenen sonuçtan söz ediyor. En büyük kalite farkı burada: [gorev-acma.md](gorev-acma.md) kalıbındaki kabul ölçütü ve test senaryosunu doldur; bilinmiyorsa "teyit bekliyor" yaz, uydurma.

Hata kaydında yeniden üretme adımı, beklenen ve gerçekleşen sonuç, ortam ve varsa ekran görüntüsü olsun.

# vSRM task rehberi

Amaç: developer ve testçinin soru sormadan başlayabileceği, ekran görüntüleriyle açıklanmış task dokümanı. Modülden bağımsızdır; ekran, entegrasyon ve bakım işlerinin hepsinde aynı biçim kullanılır. Tek cümlelik Jira taslağı için [gorev-acma.md](gorev-acma.md) yeterlidir, bu rehber büyük veya ekranlı işler içindir.

## Başlamadan önce

Şunlar yoksa sor, tahmin etme:

- Hangi işler: task numarası, başlık, sorumlu, kaynak (liste satırı, toplantı, karar).
- Müşteri kısa adı ve proje.
- Ekran kaynağı: `cikti/` içindeki şablon çıktısı, danışmanın verdiği görüntü veya test ortamı.

Danışman gerçek müşteri kaydı verirse kullanma, temsili değerle devam et. Test ortamında yalnız `test.vsrm.net` açılır, giriş yapmayı danışman üstlenir, canlı ortam açılmaz.

## Çıktı

`cikti/task-rehberi-<musteri-kisa-adi>-<tarih>/` klasörü:

| Dosya | İçerik |
|---|---|
| `Task_Rehberi.html` | Bütün tasklar. [task-rehberi-sablon.html](task-rehberi-sablon.html) kopyasından üretilir, şablonun kendisi değiştirilmez. |
| `Task_Rehberi.pdf` | Aynı içerik. Tarayıcıdan yatay A3 yazdırılır. |
| `Gorseller/NN-ekran-adi.png` | İşaretli ekran görüntüleri. |
| `<task-no>_Jira_Aciklamasi.txt` | Jira açıklamasına yapıştırılacak düz metin. |

Excel yalnız danışman isterse üretilir; bu durumda ilk sayfa task listesi, her task kendi sayfasıdır.

## Her taskın bölümleri

Sırayı değiştirme. İçi boş bölümü silme, "Kaynakta yok, teyit bekliyor" yaz.

1. **Başlık:** `Task <no> · <konu - ad haline gelmiş iş>`. Altında sorumlu ve kaynak.
2. **Bağımlılıklar:** Önce bitmesi gereken task ve kararlar, numarasıyla.
3. **Mevcut durum ve hedef:** Bugün ne oluyor, bu iş neyi değiştiriyor. Görsel prototipse "canlıda tamamlandığı anlamına gelmez" yaz.
4. **İstenen geliştirme:** Numaralı maddeler. Her madde tek davranış anlatır.
5. **Ayrıntı tabloları:** Numaralı başlıklarla, aşağıdaki kalıplarla.
6. **Kabul kriterleri:** Numaralı, test edilebilir.
7. **Kapsam sınırı:** Bu işin yapmadığı ve hangi taskta yapıldığı.
8. **Teknik teyit özeti:** Uygulamadan önce doğrulanacaklar.
9. **Görseller:** İşaretli ekran ve numara açıklamaları.
10. **Kaynaklar:** Toplantı, karar, belge, liste satırı.
11. **Notlarım / Aksiyonum:** Danışman için boş alan.

## Ayrıntı tabloları

Tablolar üç sütunludur, her satır tek alan veya tek adımdır.

| İş türü | Tablo | Sütunlar |
|---|---|---|
| Ekran | Kullanıcı akışı ve ekran sınırları | Adım / ekran · Yapılacak işlem · Veri ve beklenen davranış |
| Ekran | Her ekranın alanları | Alan / görünüm · Veri kaynağı ve kapsam · Giriş, gösterim ve kontrol |
| Ekran | İşlemler ve düğmeler | Alan / işlem · Kaynak / hesap · Beklenen davranış |
| Entegrasyon | Alan eşleme | Hedef alan · Kaynak · Dönüşüm, zorunluluk ve hata |
| Entegrasyon | Akış | Tetikleyici · Yapılan işlem · Başarı ve hata sonucu |
| Bakım tablosu | Alanlar | Alan · Tip ve zorunluluk · Yetki ve kontrol |

Ortak kolon ve alan adlarını ekrandaki adıyla yaz. Salt okunur alanı "Salt okunur" diye belirt.

## Kabul kriterleri

- Her istenen geliştirme en az bir kriterle karşılanır.
- Miktar veya kural varsa sayılı örnek ver: "100 adetlik kayıtta 60 kabul ve 20 şartlı kabul varsa uygun miktar 80 olur."
- Olumsuz durumu yaz: yetkisiz kullanıcı, eksik bilgi, mükerrer kayıt, iki kullanıcının aynı anda işlemi.
- Tekrar çalıştırmayı yaz: aynı onay ikinci kez kayıt çoğaltmaz.
- Kaynakta yoksa "Öneri (teyit bekliyor):" ile başlat. Örnek süreci müşteri kuralı gibi sunma.

## Görseller

- Her görsel tek ekranın ilgili bölümünü gösterir. Gereksiz boş alanı kırp.
- İncelenecek yeri numaralı kırmızı çerçeveyle işaretle, görselin altına `numara · ne yapılacak` tablosu koy. Metindeki numara görseldekiyle aynı olmalı.
- Ekrandaki değerler temsili olmalı. Gerçek müşteri, kişi veya belge numarası görünüyorsa görseli kullanma.
- Her görselin kaynağını yaz: prototip, test ortamı veya danışmanın verdiği görüntü.

Tarayıcı aracında işaretlemek için sayfada şunu çalıştır, ekran görüntüsü aldıktan sonra sayfayı yenile. `kok` görüntüsü alınacak kutu, `alanlar` işaretlenecek öğelerdir:

```js
(({kok,alanlar})=>{const h=document.querySelector(kok);h.style.position='relative';alanlar.forEach((s,i)=>{const e=document.querySelector(s);if(!e)throw Error(s);e.style.outline='3px solid #cc3c19';const n=document.createElement('b');n.textContent=i+1;n.style.cssText='position:absolute;background:#cc3c19;color:#fff;font:bold 13px Arial;padding:2px 4px;z-index:2147483647';const r=e.getBoundingClientRect(),b=h.getBoundingClientRect();n.style.left=Math.max(0,r.left-b.left)+'px';n.style.top=Math.max(0,r.top-b.top-16)+'px';h.append(n);});})({kok:'#ekran',alanlar:['#alan1','#alan2']})
```

Görsel alınamıyorsa yerini boş bırakma: "Görsel bekliyor: <ekran>" yaz ve danışmana söyle.

## Uydurma

JSP, veritabanı kolonu, API adı, entegrasyon alan kodu veya sürüm numarası kaynakta yoksa yazma. Bunları Teknik teyit özeti'ne "doğrulanacak" diye al. Görülmeyen ekranı görmüş gibi anlatma.

## Teslimden önce

1. PDF'in sayfalarını görsel olarak kontrol et: tablo kesilmiyor, satır taşmıyor.
2. Her istenen geliştirmenin kabul kriteri var.
3. Görsel numaraları metinle eşleşiyor.
4. Çıktıda şablon yer tutucusu (`{{`) kalmadı.
5. Gerçek müşteri verisi yok.

Danışmana klasörün yerini, kaç task üretildiğini, açık teyitleri ve eksik görselleri söyle. Kuralların süreç sahibince onaylanması gerektiğini belirt. Jira'ya kendin yazma.

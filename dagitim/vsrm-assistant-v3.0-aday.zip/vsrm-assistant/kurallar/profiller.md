# Tasarım profili: classic-v5

Paketteki tüm ekranlar tek profil kullanır. Değerler çalışan vSRM ekranından ölçülmüştür. Yapı ve yoğunluk için [referans](referans) görsellerine bak. Öncelik sırası: uyarladığın şablonun mevcut değeri, sonra aşağıdaki ölçüler, sonra görsel.

## En sık yapılan hatalar

- **Büyük yazı.** Tüm metin 11px'tir: tablo, form, düğme, sekme. 13-14px kullanma.
- **Geniş boşluk.** Hücre boşluğu 3px'tir. Ekran yoğun görünmelidir.
- **Sade kabuk.** Menü çubuğu, araç satırı ve sekme satırı ayrı ayrı bulunur; birini atlama.
- **Modern kart görünümü.** Gölgeli kart, geniş başlık, büyük KPI kutusu yoktur. Hiyerarşi gri bantlarla kurulur.

## Ölçülmüş değerler

| Öğe | Değer |
|---|---|
| Yazı | Arial, Helvetica, sans-serif; 11px |
| Sayfa | Zemin `#FFFFFF`, metin `#004286` |
| Üst alan | 45px, düz zemin `#F0F4FB`, üstte 4px `#70429B` çizgi |
| Satır yüksekliği | İçerik belirler: düz metin 20-36px; satır içi kutu veya düğme varsa 45-50px |
| Menü çubuğu `#menuBar` | Yükseklik 27px; zemin `#00C2E7`; beyaz metin; menüler `▼` ile |
| Sekme | 30px; padding 6px 10px; 11px; köşesiz. Pasif: zemin `#D7DDE4`, siyah metin, normal. Seçili: zemin `#67809F`, beyaz metin, kalın |
| Düğme `.button.button-vedi` | 11px; padding 1px 5px; radius 25px; zemin `#E1E5EC`; kenar `#CCCCCC` |
| Metin kutusu | 19px; padding 0 3px; köşesiz; kenar `#888888` |
| Kolon filtre kutusu | 20px; radius 10px; kenar `#DDDDDD` |
| Tablo başlığı | İki satır. Kolon filtre satırı zemin `#EEF3F7`, başlık satırı zemin `#DDDDDD`. 11px kalın; padding 3px; metin `#004286`; ortalı |
| Tablo hücresi | 11px; padding 3px; metin `#003D7D`; kenar `#E4E9EF` |
| Satır zemini | Sırayla `#F0F4FB` ve `#FFFFFF` |
| Bölüm bandı | Zemin `#EEE`→`#CCC`; 11px; padding 4px |
| Filtre alanı | Zemin `#F8F8F8`; padding 7px 10px |

Düğme rolleri: Ekle `#67809F`, Sil `#E7505A`, Güncelle `#F3C200`, Bul `#E1E5EC`. Bağlantı `#004286`, üzerine gelince `#F48E00`.

Durum hapları: `.backtgreen2` `#C5DACD` uygun, `.backtyellow` `#DCDC83` bekliyor, `.backtred2` `#DAC5C5` engelli.

Footer ve sürüm bilgisini doğrulanmış ürün bilgisine göre koru; örnekteki eski sürümü yeni ürünün sürümü gibi sunma.

# Canlı ekran arayüzü

Canlı ihale gibi yoğun, gerçek zamanlı ekranlar için tasarım dili. Klasik V5 ekranların yerine geçmez: hazırlama, bakım ve liste ekranları `profiller.md` ile yapılır. Değerler bitmiş e-ihale ürününden ölçülmüştür.

## İki dil, tek ürün

- Portal kabuğu her ekranda aynıdır ve Arial kullanır: logo, başlık, cyan menü (`#00C2E7`), rol seçimi.
- Hazırlama ekranları klasik V5'tir: Arial 11px; tamamlanan adım `#5BD75B`, aktif adım `#87A6CC`.
- Canlı oda modern dildir. Klasik stili canlı odaya, canlı stili hazırlamaya taşıma; her biri kendi kök sınıfı altında kapsamlanır (`main.legacy-mode`, `main.live-mode`).

## Temel değerler

| Öğe | Değer |
|---|---|
| Sayfa zemini | `#F0F5F8` |
| Ana metin | `#173149` lacivert |
| Vurgu | `#147D87` teal; koyu tonu `#126E78` |
| İkincil metin | `#60758A`, `#6E8193` |
| Kart | Beyaz; kenar `#DAE4EC`; radius 13px; padding 12px; gölge yok |
| Bilgi şeridi | Zemin `#E8F2F2`; kenar `#CBDFE1`; radius 13px |
| Yazı | Inter 13px/1.5; başlıklarda Plus Jakarta Sans |
| Sayfa başlığı | Plus Jakarta Sans 23px 700; harf aralığı -0.7px |
| Kart başlığı | Inter 12px 600; harf aralığı -0.3px |
| Yoğun metin | Etiket ve tablo 10px; tablo başlığı 9px 500 |
| Sayılar | `font-variant-numeric:tabular-nums`, para ve süre sağa hizalı |

Fontlar yerel WOFF2 olarak gömülür; dış bağlantı kullanılmaz.

## Yerleşim

- Üç kolon: sol 308px, orta esnek, sağ 310px. Kolon arası boşluk küçük ve eşittir.
- Sol: süre kartı, ihale bilgileri.
- Orta: bilgi şeridi, grafik, teklif tablosu. Rakamlar burada okunur.
- Sağ: role göre değişir. Ana firma yönetim ve mesaj görür, tedarikçi teklif formu görür.
- Üst satır: başlık, sekmeler, Duyurular ve Mesajlar hapları aynı hizada.
- Yatay sayfa kaydırması yoktur. Geniş tablo kendi alanında kayar.

## Bileşenler

**Süre kartı:** Zemin `#173149`, beyaz metin, radius 13px. İçinde ince çerçeveli iki satır: ihale süresi ve tur süresi. Sağ üstte durum rozeti. Geri sayım büyük ve tabular.

**Sekmeler:** 10px, üst köşeler 8px. Pasif `#647B8A` 600. Seçili `#126E78` kalın, zemin `#E3F1EF`, altta çizgi.

**Düğmeler:** Hap biçimli, radius 100px.

| Rol | Görünüm |
|---|---|
| Birincil, başlat | Yeşil `#188753`, beyaz metin |
| Birincil, gönder | Teal `#147D87`, beyaz metin |
| İkincil | Saydam zemin, ince kenar, teal metin |
| Durdur | Sarı zemin, koyu metin |
| Tehlikeli | Zemin `#FFF0F1`, kenar `#CB3348`, metin `#AD2036`, kalın |

**Tablo:** Başlık 9px `#736E7A`, zemin `#FAFAF8`; hücre 10px `#333`, padding 2px 6px; yalnızca yatay ince çizgi. Sıralama kolon başlığından yapılır.

**Grafik:** Her firma sabit renk, her kabul edilmiş teklif odaklanabilir nokta. Filtreler üstte, tooltip firma/tur/zaman/tutar gösterir. Tedarikçi yalnızca kendi verisini görür.

**Boş durum:** Yüksekliği korur ve ne beklendiğini söyler (`Teklif bekleniyor`). Boş alan bırakma.

## Hareket

Hareket bilgi taşır, süs değildir:

- `auctionLivePulse`: Canlı rozeti.
- `countdownUrgent`: Son 120 saniyede kırmızı sayaç.
- `activityCountPulse`: Yeni hareket sayacı.
- `unreadBadgePulse`: Okunmamış rozet.
- `headingBannerIn`: Başlık bildirimi girişi.

Duraklama ve kapanışta hareket durur. `prefers-reduced-motion` tümünü kapatır.

## Davranış ilkeleri

- Tek bilgi tek yerde durur. Üstte tekrar eden Canlı, bağlantı başarılı ve teklif adedi bantları olmaz; yalnızca sorun olduğunda uyarı çıkar.
- Rol ayrımı ekran düzeyinde başlar: Rakip kimliği ve verisi tedarikçi görünümüne hiç girmez.
- Düzenleme taslak üzerinde yapılır. Kaydet topluca uygular, Vazgeç atar; hata varsa Kaydet pasiftir ve neden görünür.
- Kritik bilgi tooltip içinde saklanmaz. Tooltip klavyeyle de açılır.
- Klavye odağı görünür olur: `outline:2px solid #147D87`, `outline-offset:3px`.
- Simülasyon olduğu ekranda söylenir; demo davranışı entegrasyon gibi sunulmaz.
- Para `tr-TR` biçiminde ve `₺` ile yazılır. Tamamlanmamış sıralama demo olarak etiketlenir.
- Manuel uzatma ihale süresini uzatır, tur süresini değiştirmez.

## Kontrol listesi

Canlı ekranı teslim etmeden önce: 1280px ve 1600px genişlikte yatay kaydırma yok, süre kartı kısa ekranda görünür, iki rol ayrı ayrı denendi, boş ve dolu durumlar görüldü, azaltılmış hareket denendi, konsol temiz.

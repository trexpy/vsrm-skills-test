# V5 teknik bileşen referansı

Özgün kaynağın teknik bölümleri korunmuştur. Profil, kapsam ve açıklama soruları için `ekran-uretim-rehberi.md` geçerlidir; aşağıdaki tarihsel zorunlu sorular mevcut kararların tekrar sorulmasını gerektirmez. Ölçülmüş değerler profiller.md içindedir.

## 1. ANA SAYFA VE MENÜ

Ana sayfa ve ana menü olarak **daima** `exVSRM_anasayfa_bos.html` kabuğu kullanılır. Yeni/uydurma bir ana sayfa veya menü tasarlanmaz.

Kabuk yapısı:
- `#topArea` → logo bandı: `#logoCell` | `#brandCell` (`.vendorName` = "VSRM", `.userName` = "Kullanıcı X") | `#logoCellRight`
- `#menuBar` → mavi bant `#00C2E7`, 20px yükseklik; içinde `#menuRoot` (MENU JSON ağacından üretilen menü) ve sağda `#clock`
- `#content` → boş içerik alanı
- Menü öğesi: `.mi > a` beyaz 11px, hover `#00A9CC`; alt menü `ul.sub` zemin `#00C2E7`, çerçeve `1px #8399A1`

Sayfanın en altında **daima** footer bulunur:
```html
<table id="footerTableP" class="fdgray pdf-hide" width="100%" border="0" cellspacing="0" cellpadding="1">
  <tr><td align="right">v14.08.1, Copyright ©2001-2026 ITG Ltd.</td></tr>
</table>
```

---

## 2. RENK VE TİPOGRAFİ TOKENLARI (dstyles/style.jsp)

Font her yerde **Arial/Helvetica 11px**. Başlık bantları 12px, dt-filter placeholder 10px italik.
**Görsel hiyerarşi font büyüklüğüyle değil ZEMİN RENGİYLE kurulur.**

### Yazı renkleri
| Sınıf | Renk |
|---|---|
| `.fddgray` | #303030, Arial 11px |
| `.fdgray` | #808080 |
| `.fdblue` | #004286 |
| `.fwhite` | #FFFFFF |
| `.fddgray12` | #404040, 12px |

### Input sınıfları
| Sınıf | Tanım |
|---|---|
| `.itblack` | Arial 11px — standart metin input |
| `.idblack` | Arial 11px, `cursor:pointer`, `text-align:center` — **tarih input** |
| `.irblack` | Arial 11px, `text-align:right` — **sayısal input** |
| `.ibblack` | Arial 11px — buton tipi input |

### Zemin renkleri
| Sınıf | Renk |
|---|---|
| `.backgray` | #F8F8F8 |
| `.backdgray` / `.backtgra` | #CCCCCC |
| `.backNtgra` | üst 1px #CCC çerçeve + zemin #CCCCCC |
| `.backwhite` | #FFFFFF |
| `.backtblue` | #B6D6EA |
| `.backtblue2` | #D7DDE4 |
| `.backtblue3` | #B7BDDD |
| `.backtgreen` | #93FF95 |
| `.backtgreen2` | #C5DACD |
| `.backtyellow` | #DCDC83 |
| `.backtbrown` | #EEC684 |
| `.backtred` | #FF9A95 |
| `.backtred2` | #DAC5C5 |
| `.backtpurple` | #800080 |
| `.backtlightblue` | #99CCFF |
| `.backtlightpink` | #FF99CC |

### Durum renkleri
| Sınıf | Renk / Etki |
|---|---|
| `.required` | #FA7885 |
| `.requiredBg` / `.requiredBackground` | mistyrose #FFE4E1 — **zorunlu alan** |
| `.disabledBackground` / `.isDisabled` | #F4F4F4, opacity .5, renk #676A6C |
| `.targetable` | #F85454 zemin, beyaz yazı |
| `.cwarning` | #FFFFEE zemin, #864200 yazı |
| `tr.rowSelection.active td` | #DBE0E5 |
| `td.highlighted-td` | #B0E2FF |

### Kenarlıklar ve diğer
| Sınıf | Tanım |
|---|---|
| `.borderAgray` | 1px solid #EEEEEE |
| `.borderAdgray` | 1px solid #CCCCCC |
| `.tableborder` | `border-collapse: collapse` |
| `.tr1` / `.tr2` | #FFFFFF / #F0F0F0 |
| `.chand` | `cursor: pointer` |
| `.fixedsize` | width 100px |
| `.fixedsize2` | max-width 150px |
| `.is150` | width 150px |
| `.inputSmall` | width 150px |
| `.inputXSmall` | width 100px |

Link renkleri: `a` = #004286, `a:hover` = #F48E00

---

## 3. BUTONLAR (styles/button.css)

Temel kabuk `.button.button-vedi`:
```css
border-radius: 25px !important;
padding: 1px 5px !important;
font-size: 12px !important;
line-height: 1.44 !important;
overflow: hidden;
```

| İşlev | Sınıf | Zemin | Yazı | İkon |
|---|---|---|---|---|
| **Ekle** / Yeni Talep Yarat | `button button-vedi success` | #67809F | #FFFFFF | `fa-plus` / `fa-shopping-cart` |
| **Sil** / İade Et | `button button-vedi danger` | #E7505A | #FFFFFF | `fa-trash` / `fa-close` / `fa-remove` |
| **Güncelle** / Kapat / TEST RUN | `button button-vedi warning` | #F3C200 | #FFFFFF | `fa-edit` / `fa-reply` |
| **Bul** | `button button-vedi` (düz) | #E1E5EC | #000000 | `fa-search` |
| **Görüntüle** | `button button-vedi info` | CSS'te **tanımsız** → gri fallback (#E1E5EC) | #000000 | `fa-search` |
| KOF Formu | `button button-vedi primary` + `style="margin-right:5px;border:1px solid black"` | — | — | — |

`blue-hoki` = #67809F. `.button-xs` = padding 1px 5px, font 12px. `.button-circle` = radius 10px. `.button-icon-only` = 25×25px.

Butonlar `<div class="button-grp-wrp">` içinde gruplanır (`text-align:left; font-size:12px;` — içindeki `.button` margin 3px).

Örnekler:
```html
<button type="button" class="button button-vedi success"> Ekle <i class="fa fa-plus"></i></button>
<button type="button" class="button button-vedi danger"> Sil <i class="fa fa-trash"></i></button>
<button type="button" class="button button-vedi warning btn-menu"> Güncelle <i class="fa fa-edit"></i></button>
<button type="button" class="button button-vedi"> Bul <i class="fa fa-search"></i></button>
<button type="button" class="button button-vedi info btn-menu"> Görüntüle <i class="fa fa-search"></i></button>
<a class="button button-vedi success"> Yeni Talep Yarat <i class="fa fa-shopping-cart"></i></a>
```

### Küçük ikon butonları (`a.dt-button`)
Beyaz zemin, `1px solid #E7E7E7` çerçeve, `4px` radius, kutu ~20×18px, ikon ~16×14px.

---

## 4. ALAN TİPLERİ

Tüm alanlara loglama attribute'ları eklenir:
`data-log-old-value`, `data-log-old-text`, `data-log-field`, `data-log-line-no`, `data-log-rqd-id`

### 4.1 COMBOBOX (chosen) — BİREBİR, başka stil kullanılmaz

**İÇERİK KURALI:**
- Bir combobox alan eklenecekse **ilk seçenek daima `Seçiniz`dir** (`<option value="0">Seçiniz</option>`) ve varsayılan görünen değer odur.
- Datatable'ın **yeni kayıt (ilk satır ekleme) satırında** combobox varsa, o satırdaki değeri de **daima `Seçiniz`**tir — boş bırakılmaz, başka bir değer önceden seçili gelmez.
- Chosen markup'ında bu `<a class="chosen-single chosen-default"><span>Seçiniz</span>` ile gösterilir (`.chosen-default` rengi `#999999`).

```html
<!-- yeni kayıt satırındaki combobox -->
<select class="config itblack fixedsize chosen" style="display:none">
  <option value="0">Seçiniz</option>
  <option value="1">Adet</option>
</select>
<div class="chosen-container chosen-container-single" style="width:150px">
  <a class="chosen-single chosen-default" tabindex="-1"><span>Seçiniz</span><div><b></b></div></a>
  <div class="chosen-drop">…</div>
</div>
```

**GÖRSEL:** Combobox **daima jQuery Chosen** ile render edilir. Görünen eleman:
```html
<select class="config itblack and fixedsize chosen twin-chosen lazyLoad" id="X" name="X" style="display:none">
  <option value="0">Seçiniz</option>
  <option selected value="1">1000 - Örnek Firma</option>
</select>
<div class="chosen-container chosen-container-single" style="width:150px" id="X_chosen">
  <a class="chosen-single" tabindex="-1"><span>1000 - Örnek Firma</span><div><b></b></div></a>
  <div class="chosen-drop">
    <div class="chosen-search"><input type="text" autocomplete="off"></div>
    <ul class="chosen-results"></ul>
  </div>
</div>
```

`.chosen-container-single .chosen-single` stili:
```css
position: relative; display: block; overflow: hidden;
padding: 0 0 0 8px;
height: 23px; line-height: 24px;
border: 1px solid #AAAAAA;
border-radius: 5px;
background: linear-gradient(#FFFFFF 20%, #F6F6F6 50%, #EEEEEE 52%, #F4F4F4 100%) padding-box;
box-shadow: inset 0 0 3px #FFFFFF, 0 1px 1px rgba(0,0,0,.1);
color: #444444; white-space: nowrap; text-decoration: none;
```
**Yani: hafif dikey gradientli, 5px yuvarlatılmış, #AAA çerçeveli, 23px yüksekliğinde kutu — düz/köşeli native select görünümü DEĞİL.**

- `.chosen-single span` → `display:block; overflow:hidden; margin-right:26px; text-overflow:ellipsis;`
- Ok: `.chosen-single div` → `position:absolute; top:0; right:0; width:18px; height:100%;`; içindeki `b` → `background:url(chosen-sprite.png) 0 2px no-repeat` (aşağı bakan gri dolu üçgen; açıkken `-18px 2px` ile yukarı üçgen)
- Placeholder metin `.chosen-default` → #999999
- Aktif: `.chosen-container-active .chosen-single` → border #5897FB + `box-shadow: 0 0 5px rgba(0,0,0,.3)`
- Açık: `.chosen-with-drop .chosen-single` → alt köşe radius 0, gradient ters (#EEE 20% → #FFF 80%)
- Açılır liste `.chosen-drop` → beyaz zemin, 1px #AAA yan/alt çerçeve, radius `0 0 4px 4px`, `box-shadow: 0 4px 5px rgba(0,0,0,.15)`
- `.chosen-results li.highlighted` → zemin #3875D7, beyaz yazı
- **ZORUNLU combobox:** `requiredBg` sınıfı → `.requiredBg > .chosen-single { background: mistyrose !important; }` (gradient yerine düz #FFE4E1; çerçeve ve radius aynı kalır)
- Standart container genişliği **150px** (`fixedsize` / `inputXSmall` → 100px)

### 4.2 EDIT TEXT
```html
<input type="text" class="itblack config" size="12" maxlength="30">
```
Datatable içinde: `class="itblack inputSmall"` (150px). Kısa: `inputXSmall` (100px).
Readonly/disabled: `class="is150 isDisabled custom-field" readonly` veya `disabled`.

### 4.3 NOTE (çok satırlı)
```html
<textarea class="config itblack" rows="1|3|5" cols="30|45|50" maxlength="N"></textarea>
```

### 4.4 SAYISAL
- Ondalık: `<input class="onlyFloating config itblack requiredBg" size="8" value="0.00">`
- Sağa dayalı: `<input class="config irblack" type="text" size="10" value="0.00">`
- Hücre sınıfı: `<td class="dt-center quantity__tr text-center input-number">`

### 4.5 TARİH
```html
<input readonly type="text" class="config idblack" size="12" value="Ağu 28, 2026">
```
Zorunlu ise `requiredBg` eklenir. Format **daima "Ağu 28, 2026"**, saatli ise **"Ağu 28, 2026 14:34"**.
Aralık filtresi: iki `idblack` input arasına `-` konur (`sXDateStart` / `sXDateEnd`).

### 4.6 CHECKBOX
```html
<input type="checkbox" class="itblack config" value="y">
```

### 4.7 RADIO BUTTON
Bootstrap `.radio` / `.radio-inline` — `padding-left:20px; min-height:20px; font-weight:normal;`

### 4.8 BUTON TİPLİ ALAN
```html
<button type="button" class="button button-vedi primary" style="margin-right:5px;border:1px solid black">Yeni KOF Talebi Oluştur</button>
```

### 4.9 SATIR İÇİ KOPYALAMA (alta kopyala)
Değeri alttaki tüm satırlara kopyalar. Hücreye `data-has-copy-icon="true"` verilir, alanın hemen ardına ikon eklenir:
```html
<td data-has-copy-icon="true">
  ...alan...
  <a><img src="/vedi/images/copy.png" border="0"></a>
</td>
```

---

## 5. TARİH SEÇİM KOMPONENTİ (calendar.css)

Tarih alanına tıklanınca alanın hemen **altında** `.caldiv` açılır (`position:absolute; width:200px; height:160px; z-index:99`).

```html
<div class="calbor4">
<table class="calbor5" width="100%" border="0" cellspacing="0" cellpadding="0">
  <tbody><tr><td>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tbody><tr><td>
        <table class="calhead1" width="100%" border="0" cellspacing="1" cellpadding="0">
          <tbody><tr align="center">
            <td width="1%"><img class="calhand" src="/vedi/images/calydec.gif" onclick="calYdec()" alt="Previous Year" width="15" height="15" border="0"></td>
            <td width="1%"><img class="calhand" src="/vedi/images/calmdec.gif" onclick="calMdec()" alt="Previous Month" width="15" height="15" border="0"></td>
            <td id="month" width="94%">Ağustos 2025</td>
            <td width="1%"><img class="calhand" src="/vedi/images/calminc.gif" onclick="calMinc()" alt="Next Month" width="15" height="15" border="0"></td>
            <td width="1%"><img class="calhand" src="/vedi/images/calyinc.gif" onclick="calYinc()" alt="Next Year" width="15" height="15" border="0"></td>
            <td width="1%"><img class="calhand" src="/vedi/images/calreset.gif" onclick="calClear()" alt="Clear Date" width="15" height="15" border="0"></td>
            <td width="1%"><img class="calhand" src="/vedi/images/calclose.gif" onclick="calHide()" alt="Close Calendar" width="15" height="15" border="0"></td>
          </tr>
        </tbody></table>
      </td></tr>
      <tr><td>
        <table class="caldays" width="100%" border="0" cellspacing="0" cellpadding="3">
          <tbody><tr class="calhead2" align="center">
            <td width="14%">Pzt</td><td width="14%">Sal</td><td width="14%">Çar</td><td width="14%">Per</td>
            <td width="14%">Cum</td><td width="14%">Cmt</td><td width="14%">Paz</td>
          </tr>
          <!-- 6 satır × 7 hücre = 42 hücre -->
          <!-- dolu:  <td id="dayN" width="14%" onmouseover="dayon(this)" onmouseout="dayoff(this)" onclick="daysel(this)" class="calhand">15</td> -->
          <!-- boş:   <td id="dayN" width="14%" onmouseover="dayon(this)" onmouseout="dayoff(this)" onclick="daysel(this)" class="">&nbsp;</td> -->
        </tbody></table>
      </td></tr>
    </tbody></table>
  </td></tr>
</tbody></table>
</div>
```

Renkler:
| Sınıf | Tanım |
|---|---|
| `.calhead1` | zemin **#D6D6CE**, bold Arial 11px, **siyah** |
| `.calhead2` | zemin **#848484**, bold Arial 11px, **BEYAZ** |
| `.caldays` | zemin **#FFFFFF**, Arial 11px, **SİYAH** (gün numaraları siyahtır — mavi/turuncu DEĞİL) |
| `.calhandl` | hover/seçili gün → zemin **#08216B**, beyaz yazı |
| `.calhand` | `cursor: pointer` |
| `.calbor4` | 1px; üst/sol #848484, alt/sağ #FFFFFF |
| `.calbor5` | 1px; üst/sol #000000, alt/sağ #D6D6CE |
| `.calbase` | 1px solid #000000 |

Nav butonları 15×15px, 3B çerçeveli kare:
- **Yıl** butonları (`calydec`, `calyinc`) → **TURUNCU #FF7300** zemin, siyah üçgen
- **Ay** butonları (`calmdec`, `calminc`) ve `calreset` ("c"), `calclose` ("x") → **GRİ #CECECE** zemin

---

## 6. İKON GÖRSELLERİ

FontAwesome ile taklit **edilmez**; `/vedi/images` altındaki gerçek dosyalar kullanılır.

| Dosya | Görünüm | Kullanım |
|---|---|---|
| `view.gif` (~17×15) | Beyaz kağıt sayfası üzerinde sol altta **cyan/turkuaz mercekli, koyu mavi saplı büyüteç** | Search help / seçim ikonu |
| `copy.png` (~16×20) | Üst üste binmiş **iki açık mavi/lavanta kağıt sayfası** (arkadaki sol üstte, öndeki sağ altta), koyu mavi-mor çerçeveli, içlerinde açık mavi metin çizgileri | Alt satıra kopyala |
| `attachmentList.gif` (~16×20) | **İnce siyah kontur ataç (paperclip)**, dolgusuz | Dosya eki — Dahili ve Harici için **aynı ikon** |
| `note.jpg` | Not ikonu | `img-internal-note` sınıfıyla mavimsi (`hue-rotate(150deg)`) |

**Datatable ikonları — bunlar FontAwesome'dır** ve **DAİMA 4 TANEDİR**. Her datatable'da dördü de bulunur:

| # | FontAwesome | title |
|---|---|---|
| 1 | `fa-download` | İndir |
| 2 | `fa-filter` (`buttons-colvis`) | Sütunları Filtrele |
| 3 | `fa-cog` | Tablo Görüntüleme Ayarlarını Kaydet |
| 4 | `fa-cogs` | Sütun Ayarları |

```html
<div class="dt-buttons">
  <a class="dt-button buttons-collection" tabindex="0" aria-controls="{id}" title="İndir"><span><i class="fa fa-download" aria-hidden="true"></i></span></a>
  <a class="dt-button buttons-collection buttons-colvis" tabindex="0" aria-controls="{id}" title="Sütunları Filtrele"><span><i class="fa fa-filter" aria-hidden="true"></i></span></a>
  <a class="dt-button buttons-collection" tabindex="0" aria-controls="{id}" title="Tablo Görüntüleme Ayarlarını Kaydet"><span><i class="fa fa-cog" aria-hidden="true"></i></span></a>
  <a class="dt-button buttons-collection" tabindex="0" aria-controls="{id}" title="Sütun Ayarları"><span><i class="fa fa-cogs" aria-hidden="true"></i></span></a>
</div>
```
```css
button.dt-button, div.dt-button, a.dt-button { border:1px solid #E7E7E7; color:#595959; background-color:#FFF; background-image:none; margin:2px; border-radius:4px; }
button.dt-button:hover:not(.disabled), a.dt-button:hover:not(.disabled) { border:1px solid #E7E7E7; background-color:#EBEBEB; background-image:none; }
div.dt-buttons { float: right !important; }
```

**KONUM:** İkonlar **daima datatable gridinin sağ üst köşesine dayalıdır** — grid'in sağ kenarıyla tam hizalı. Bootstrap kolon padding'i ikonları içeri kaydırmamalıdır:
```css
.dataTables_wrapper > .row { margin-left:0; margin-right:0; }
.dataTables_wrapper > .row > [class*="col-xs-"] { padding-left:0; padding-right:0; }
```
Asla ortalanmaz, asla sola yaslanmaz.

> VSRM sunucusundaki `font-awesome.css` bu üç glifi iki tonlu (koyu lacivert + turuncu) render eder. Markup yine de sade FontAwesome'dır; ayrıca bir görsel dosya konmaz.

Not ikonu varyantları: `img-internal-note` = `hue-rotate(150deg)` (dahili) | sınıfsız = harici | `img-green-note` = `hue-rotate(90deg)` | `unread-note` = `hue-rotate(-150deg)` (okunmamış)

---

## 7. ARAMA FİLTRESİ BANDI (sfContainer)

Her liste ekranının en üstünde bulunur ve **TEK SATIRDIR** (~28px). Örnek Firmale, buton ve "Filtre Seçin" select **yan yana** durur:

```html
<table class="borderAgray and fddgray and backgray" width="100%" cellspacing="1" cellpadding="5">
 <tr><td align="center">
  <table class="backNtgra and fddgray" width="100%" cellspacing="0" cellpadding="3">
   <tr><td id="sfContainer">
     <span class="sf-toggle-btn" title="Show/Hide Search Filters">▼</span>
     <div class="searchFilterMenuWrp">
       <div id="searchFilterMenu">
         <a class="button button-xs blue-hoki button-circle" id="searchFilterMenuBtn" title="Arama Filtreleri">Arama Filtreleri <span><i class="fa fa-search"></i></span></a>
         <select id="userFilterSelectId" class="userFilterSelect"><option disabled selected>Filtre Seçin</option></select>
         <div id="searchFilterOptions">
           <li>
             <a id="userSFSSaveDefaultBtn" class="dt-button" title="Seçimi Başlangıç Filtresi Olarak Kaydet"><span><i class="fa fa-bookmark-o"></i></span></a>
             <a id="userSFSUpdateBtn" class="dt-button" title="Seçimi Güncelle"><span><i class="fa fa-refresh"></i></span></a>
             <a id="userSFSDeleteBtn" class="dt-button" title="Seçimi Sil"><span><i class="fa fa-trash"></i></span></a>
           </li>
           <li>
             <input id="userSFSName" class="m-t-3" type="text" maxlength="75" placeholder="Yeni Filtre Adı">
             <a id="userSFSClearBtn" class="dt-button" title="Seçimleri Temizle"><span><i class="fa fa-eraser"></i></span></a>
             <a id="userSFSSaveBtn" class="dt-button" title="Yeni Filtre Oluştur"><span><i class="fa fa-save"></i></span></a>
           </li>
         </div>
       </div>
     </div>
   </td></tr>
  </table>
 </td></tr>
</table>
```

```css
#sfContainer{ position:relative; white-space:nowrap; }
.searchFilterMenuWrp{ display:inline-block; vertical-align:middle; }
#searchFilterMenu{ display:inline-flex; align-items:center; position:relative; }
.sf-toggle-btn{ background:#67809F !important; color:#FFF !important; padding:3px 8px !important;
  border-radius:3px !important; font-weight:bold !important; font-size:12px !important;
  display:inline-block; vertical-align:middle; cursor:pointer !important; }
#searchFilterMenuBtn{ background-image:none; margin:0 6px; font-size:12px; padding:2px 13px; white-space:nowrap; }
.userFilterSelect{ height:22px; width:150px; font-size:12px; border-radius:3px;
  border:1px solid #C4C4C4; background:#FFF; vertical-align:middle; float:none; }
/* Kaydet/güncelle/sil katmanı bandın YÜKSEKLİĞİNİ ETKİLEMEZ */
#searchFilterOptions{ position:absolute; top:100%; left:0; width:285px; margin-top:4px; padding:8px 6px;
  background:#FFF; border:1px solid #67809F; border-radius:5px; z-index:100;
  opacity:0; visibility:hidden; transition:opacity 250ms, visibility 250ms; }
#searchFilterMenu.open #searchFilterOptions{ visibility:visible; opacity:1; }
```

## 8. LİSTE EKRANI ŞABLONU (rfqRequestList.jsp)

"Arama filtresi + filtre alanları + hemen altında datatable" istendiğinde **otomatik** bu iskelet kurulur:

1. `sfContainer` arama filtresi bandı (bkz. §7)
2. **Filtre alanları ızgarası** — yerleşim kuralı: alanlar **sol en üstten** başlar, her blok **en fazla 4 satırdır**, blok dolunca yenisi **sağda** açılır (satır bazlı değil, **sütun bazlı** doldurma). Etiketler **daima sola dayalı**. **Bul** ve varsa ana aksiyon butonu **en sağdaki blokta üstte** durur.

```html
<table id="searchFilterTable" width="100%" border="0" cellspacing="0" cellpadding="0">
 <tr>
  <td valign="top">
    <table class="fddgray" border="0" cellspacing="5" cellpadding="1">
      <tr><td align="left" nowrap>Şirket</td><td nowrap>…alan…</td></tr>
      <tr><td align="left" nowrap>Fabrika</td><td nowrap>…alan…</td></tr>
      <tr><td align="left" nowrap>Depo Yeri</td><td nowrap>…alan…</td></tr>
      <tr><td align="left" nowrap>Proje Kodu</td><td nowrap>…alan…</td></tr>   <!-- MAX 4 SATIR -->
    </table>
  </td>
  <td valign="top">…sonraki 4 satırlık blok…</td>
  <td valign="top">…sonraki blok…</td>
  <td valign="top" class="button-grp-wrp" nowrap>
    <button type="button" class="button button-vedi"> Bul <i class="fa fa-search"></i></button>
    <a class="button button-vedi success"> Yeni Talep Yarat <i class="fa fa-shopping-cart"></i></a>
  </td>
 </tr>
</table>
```
```css
#searchFilterTable td{ text-align:left; }
#searchFilterTable > tbody > tr > td{ vertical-align:top; padding-right:18px; }
```
Not: wizard/form içindeki `headerTable` etiketleri `align="right"` kalmaya devam eder. **İlk satırın sonunda** `<td class="button-grp-wrp">` içinde **Bul** + varsa ana aksiyon butonu (ör. "Yeni Talep Yarat")
3. Altında tam datatable bloğu

Filtre alanı tipleri:
```html
<!-- searchHelp'li çoklu seçim -->
<input mcselect="Y" class="itblack" readonly data-coltype="inputColumn" type="text" size="12" name="XNameMultiSel" id="XNameMultiSel" value="">
<a href="#" id="Popup_XNameMultiSel"><img src="/vedi/images/view.gif" border="0"></a>

<!-- düz metin -->
<input class="itblack" type="text" name="sNumber" size="12" maxlength="20" value="">

<!-- tarih aralığı -->
<input readonly type="text" class="idblack" size="12" name="sCreationDateStart" value="Tem 28, 2026"> -
<input readonly type="text" class="idblack" size="12" name="sCreationDateEnd" value="Ağu 28, 2026">

<!-- statü / kısa liste (chosen ile render edilir) -->
<select class="itblack inputCenter inputXSmall" name="sStatus" id="sStatus">
  <option selected value="">Hepsi</option><option value="Y">Aktif</option><option value="N">Pasif</option>
</select>
```

---

## 9. DATATABLE

> **Kaynak: `VSRM_Datatable_Template3` / `supplierRegistrationList2.jsp`.**
> Bu **tek ve geçerli** datatable standardıdır. Önceki datatable tanımları geçersizdir.

### 9.1 Yerleşim — fit to page ve sola dayalı

- Dış sarmalayıcı: `<div id="page-wrp" style="float:left">` → tablo **daima sola dayalıdır** ve sayfa yeniden boyutlandırıldığında da sola dayalı kalır.
- `.dataTables_wrapper` → `width: 95vw; margin: 0 auto; padding: 6px 13px 3px; background:#FFF; border:1px solid #D1D1D1; font-size:11px`
  Yani **fit to page**: genişlik sayfa genişliğine göre belirlenir. **Sütun sayısı arttıkça tablo sağa doğru büyümez**; sağdan ve soldan pay bırakır, fazlalık için **altta yatay scroll** çıkar.
- `#page-wrp .dt-tb-wrp { overflow-x: auto; min-height: 0; }`
- Tablo: `width="100%" style="width:100%"`, `.dataTable { border: 1px solid #E3E3E3; }`
- **Sütun genişliği** başlangıçta **auto width**'tir (DataTables `autoWidth`). Kullanıcı isterse değiştirebilir.
- **Satır (band) yüksekliği** içeriğe/sütun genişliğine göre **otomatik** ayarlanır.

### 9.2 Yapışkan başlık

```html
<div class="col-xs-12 table-content dt-tb-wrp tableStickyHead">
```
```css
/* Sabit height DEĞİL max-height: tablo satır sayısı kadar yer kaplar, altta boşluk kalmaz */
.tableStickyHead { overflow-y: auto; max-height: 60vh; }
.tableStickyHead thead:first-child tr:first-child th  { position: sticky; top: -1px; z-index: 1; background-color: #F0F3F6; }
.tableStickyHead thead:first-child tr:nth-child(2) th { position: sticky; top: 21px; z-index: 1; background-color: #F0F3F6; }
```

### 9.3 Tam iskelet

```html
<div id="page-wrp" style="float:left">
  <div id="{id}_wrapper" class="dataTables_wrapper no-footer">

    <div class="row">
      <div class="col-xs-3">
        <div id="{id}_filter" class="dataTables_filter"><label>Bul<input type="search" placeholder="" aria-controls="{id}"></label></div>
      </div>
      <div class="col-xs-6"></div>
      <div class="col-xs-3"><div class="dt-buttons">
        <a class="dt-button buttons-collection" tabindex="0" aria-controls="{id}" title="İndir"><span>…</span></a>
        <a class="dt-button buttons-collection buttons-colvis" tabindex="0" aria-controls="{id}" title="Sütunları Filtrele"><span>…</span></a>
        <a class="dt-button buttons-collection" tabindex="0" aria-controls="{id}" title="Tablo Görüntüleme Ayarlarını Kaydet"><span>…</span></a>
        <a class="dt-button buttons-collection" tabindex="0" aria-controls="{id}" title="Sütun Ayarları"><span>…</span></a>
      </div></div>
    </div>

    <div class="row"><div class="col-xs-12 table-content dt-tb-wrp tableStickyHead">
      <table cellpadding="3" cellspacing="2" border="0"
             class="fddgray display cell-border tableborder backtgra dataTable no-footer"
             width="100%" id="{id}" role="grid" aria-describedby="{id}_info" style="width:100%">
        <thead style="background-color: #EAF5FE; color: #319CDD;">
          <tr id="filterrow" role="row">
            <th class="noSearch" rowspan="1" colspan="1"></th>
            <th nowrap="" rowspan="1" colspan="1"><input type="text" style="width:155px;" placeholder=""></th>
            …
          </tr>
          <tr role="row">
            <th class="noVis noDown nowrap sorting_disabled" align="center" style="margin:5px;padding:10px;width:21px"
                rowspan="1" colspan="1" data-column-index="0" aria-label=""><input type="checkbox" class="itblack" name="toggleCB"></th>
            <th nowrap="" class="sorting" tabindex="0" aria-controls="{id}" rowspan="1" colspan="1"
                data-column-index="1" aria-label="Başvuru Numarası: artan sütun sıralamasını aktifleştir"
                style="width:132px">Başvuru Numarası</th>
            …
          </tr>
        </thead>
        <tbody>
          <tr role="row" class="odd">
            <td align="center" class=" nowrap"><input type="checkbox" class="itblack" name="detailId" value="9380"></td>
            <td nowrap="" align="center">…</td>
            …
          </tr>
        </tbody>
      </table>
    </div></div>

    <div class="row">
      <div class="col-xs-4"><div class="dataTables_info" id="{id}_info" role="status" aria-live="polite">41 kayıttan 1 - 41 arasındaki kayıtlar gösteriliyor</div></div>
      <div class="col-xs-4"><div class="dataTables_paginate paging_full_numbers" id="{id}_paginate">
        <a class="paginate_button first disabled" id="{id}_first">İlk</a>
        <a class="paginate_button previous disabled" id="{id}_previous">Önceki</a>
        <span><a class="paginate_button current">1</a></span>
        <a class="paginate_button next disabled" id="{id}_next">Sonraki</a>
        <a class="paginate_button last disabled" id="{id}_last">Son</a>
      </div></div>
      <div class="col-xs-4 text-right"><div class="dataTables_length" id="{id}_length">
        <label>Sayfada <select name="{id}_length"><option value="1500">1500</option><option value="3000">3000</option><option value="4500">4500</option></select> kayıt göster</label>
      </div></div>
    </div>

  </div>
</div>
```

### 9.4 Başlık ve filtre satırı

`thead` **iki satırdır**: önce `#filterrow`, sonra başlık satırı.

- Filtrelenmeyen sütunlarda: `<th class="noSearch" rowspan="1" colspan="1"></th>`
- Filtrelenen sütunlarda: `<th nowrap=""><input type="text" style="width:NNNpx;" placeholder=""></th>`

**Filtre kutusu stili:**
```css
.dataTable thead tr th input[type="text"] {
  height: 19px; border: 1px solid #E3E3E3; padding: 0; margin: 0;
  font-size: 11px; text-align: center; border-radius: 10px;
}
```

**Başlık renkleri, hizası ve yüksekliği:**
```css
/* Başlık satırı AUTO HEIGHT: sabit yükseklik verilmez. Sütun adı tek satıra sığıyorsa
   satır tek satırlık kalır; alt satıra geçerse yükseklik otomatik büyür. */
.dataTables_wrapper thead tr              { height:auto; min-height:23px; font-size:11px !important; background:#DDE3E9 !important; color:#2F4963 !important; font-weight:normal !important; }
.dataTables_wrapper thead:first-child tr  { vertical-align:top; background:#F0F3F6 !important; }
.dataTables_wrapper thead tr:first-child th,
table.dataTable thead th, table.dataTable thead td { margin:0; padding:1px 0; font-weight:bold; }

/* Sütun isimleri DAİMA ortalıdır — hücre içeriği sağa/sola dayalı olsa bile.
   height, tablo hücrelerinde MİNİMUM gibi davranır: tek satırlık isimde başlık ~23px
   kalır, isim alt satıra geçerse yükseklik otomatik büyür. */
table.dataTable thead th, table.dataTable thead td { text-align:center !important; vertical-align:middle; height:19px; }

/* Checkbox başlık hücresinin inline padding:10px değeri satırı şişirir; bastırılır. */
table.dataTable thead th.sorting_disabled { padding:2px 4px !important; margin:0 !important; }
```
Sarma davranışı `th` üzerindeki `nowrap` attribute'u ile belirlenir; CSS ile `white-space` zorlanmaz.

**Sıralama oku:** Ok (`sort_both.png`, gri çift üçgen) **daima sütun isminin sağında ve dikeyde ortalı** durur — asla alt satıra kaymış gibi görünmez.

Arka plan görseli (`background-position: right center`) **yetersizdir**: başlık satırı yükseldiğinde metin üstte hizalanır, ok ortada kalır ve ikinci satırdaymış gibi görünür. Doğru yöntem `::after` ile mutlak konumlandırmadır:

```css
table.dataTable thead th.sorting,
table.dataTable thead td.sorting{
  position:relative; cursor:pointer; background-image:none !important;
  padding-left:14px !important; padding-right:14px !important;   /* SİMETRİK — bkz. not */
}
table.dataTable thead th.sorting::after,
table.dataTable thead td.sorting::after{
  content:""; position:absolute; right:3px; top:50%; transform:translateY(-50%);
  width:11px; height:14px; pointer-events:none;
  background:url("/vedi/scripts/dataTables-1.10.13/media/images/sort_both.png") no-repeat center center;
  background-size:11px 14px;
}
table.dataTable thead th.sorting_disabled::after{ content:none; }
```

> **Padding neden simetrik?** Sağ boşluk, okun sütun ismiyle çakışmasını önler. Eşit sol boşluk ise ismin **tam ortalı** kalmasını sağlar. Tek taraflı padding kullanılmaz — ortalamayı bozar.


`thead` üzerindeki inline `style="background-color:#EAF5FE; color:#319CDD;"` kaynakta bulunur ama yukarıdaki `!important` kuralları tarafından ezilir; yine de birebir uyum için yazılır.

### 9.5 Satırlar

```css
table.dataTable.display tbody tr.odd  { background-color: #F0F4FB; }
table.dataTable.display tbody tr.even { background-color: #FFFFFF; }
/* Satır ayırıcı çizgi: #F0F3F6'dan ÇOK AZ daha belirgin. Daha koyu ton kullanılmaz —
   ayrım sadece hafifçe fark edilmelidir. */
table.dataTable.display tbody th,
table.dataTable.display tbody td      { border-top: 1px solid #E4E9EF; }
table.dataTable.cell-border tbody th,
table.dataTable.cell-border tbody td  { border-right: 1px solid #E4E9EF; }

/* HTML border/bordercolor attribute'u taşıyan tablolarda da çizgi rengi aynı kalsın */
table.dataTable tbody td, table.dataTable tbody th { border-color: #E4E9EF !important; }
```
Hücreler `<td nowrap="" align="center">`. Sağa dayalı sayısal sütunlarda `class=" text-right"`, ortalanmış statü sütunlarında `class=" text-center nowrap"`.

### 9.6 Üstteki "Bul" kutusu, ikonlar ve alt satır

```css
.dataTables_wrapper .dataTables_filter       { float: left; text-align: left; }
.dataTables_wrapper .dataTables_filter input { border-radius: 8px; border: 1px solid #E3E3E3; }
.DTTT_container, .dt-buttons                 { float: right !important; }
.dataTables_info     { padding-top: 12px; float: left !important; }
.dataTables_length   { float: none !important; padding-top: 6px !important; }
.dataTables_length select { border-radius: 8px; }
.dataTables_paginate { float: none !important; text-align: center !important; padding-top: 3px !important; }
button.dt-button, div.dt-button, a.dt-button { border:1px solid #E7E7E7; color:#595959; background-color:#FFF; background-image:none; margin:2px; border-radius:4px; }
```

**İkonlar 4 tanedir** (FontAwesome: `fa-download` · `fa-filter` · `fa-cog` · `fa-cogs`) ve daima **datatable gridinin sağ üst köşesine dayalıdır**. Tam markup ve konumlandırma kuralı için bkz. §6.

### 9.7 "İŞLEM SEÇİNİZ" bloğu (`#optionDiv`)

**ZORUNLU DAVRANIŞ:** Bir datatable tasarlamadan önce kullanıcıya sorulur:
1. **"İşlem Seçiniz yapısını kullanmak ister misiniz?"**
2. İstiyorsa: **combobox'ta listelenecek seçenekler nelerdir?**

Yerleşim: datatable'ın **hemen üstünde**, `#page-wrp`'nin **dışında ve öncesinde**.

```html
<div id="optionDiv">
  <table class="fddgray" width="100%" border="0" cellspacing="0" cellpadding="3">
    <tr>
      <td align="left" width="5%">
        <select id="operation" name="operation" class="itblack and fixedsize chosen">
          <option value="0">Seçiniz</option>
          <option value="7">Davet Linki Gönder</option>
          <option value="8">İş Ortağı Yerine Başvur</option>
          <option value="9">Onayla</option>
          <option value="10">Reddet</option>
          <option value="11">Revizyon İste</option>
          <option value="6">SAP'ye aktar</option>
          <option value="12">Kaydı Sil</option>
          <option value="13">Onayı Üstüne Al</option>
          <option value="15">Denetim Formu Gönder</option>
          <option value="18">Yönlendir</option>
        </select>
      </td>
      <td align="left">
        <button type="button" class="button button-vedi success">İşlem Yap <i class="fa fa-check"></i></button>
      </td>
    </tr>
  </table>
</div>
```
```css
#optionDiv { border: 1px solid gray; padding: 5px; border-radius: 20px; margin: 10px 15px; }
```
Combobox chosen ile render edilir (150px), ilk seçenek daima **"Seçiniz"** (`value="0"`). Buton daima `button button-vedi success` + `fa-check`, metni **"İşlem Yap"**.

### 9.8 Client-side (satır içi düzenleme) varyantı

Görsel standart §9.1–9.6 ile **aynıdır**. Tek farkı satırların input barındırmasıdır:
- **İlk `<tr>` YENİ KAYIT satırıdır**: ilk hücrede **Ekle** butonu (`button button-vedi success`, #67809F), alanlar boş
- Sonraki satırlarda ilk hücre `<input type="checkbox" name="lineIds" value="ID">`
- Alanlar `class="itblack inputSmall"` (150px)
- Son sütunda **Görüntüle** butonu (`button button-vedi info`, gri fallback #E1E5EC)

### 9.9 Wizard detay tablosu (`detailTable_N`)

Görsel standart aynıdır. Ek olarak: sütun başlıklarına `dtype="select|input-number|number|checbox"` ve `class="{alanAdi}__tr"` verilir. Satırlar `<tr class="tr2 rowSelection odd|even" select-index="N">`, ilk hücre `<input type="checkbox" name="rqdId">`. Satır seçilince alta sekmeli panel açılır (bkz. §11.2).
```css
tr.rowSelection          { cursor: pointer; }
tr.rowSelection.active td{ border-bottom: 1px solid #C5C5C5; background: #DBE0E5; }
td.highlighted-td        { background-color: #B0E2FF !important; }
td.input-number input    { text-align: right; }
```


### 9.10 Otomatik alan ve filtre kutusu genişliği

Hem satır içi düzenlenebilir hücrelerdeki alanlar **hem de datatable'ın üstündeki `#filterrow` filtre kutuları** aynı otomatik genişlik kuralına tabidir ve auto width / autosize hesabına dahildir.

**KURAL:** Alan genişliği, bulunduğu **sütun ızgarasının solundan ve sağından 3'er mm** boşluk kalacak şekilde otomatik ayarlanır.

```css
/* Filtre kutuları — th'de yatay padding 0 olduğu için telafi gerekmez */
table.dataTable thead tr th input[type="text"]{
  width: calc(100% - 6mm) !important; box-sizing: border-box;
}

/* Satır içi alanlar — +6px, td'nin cellpadding="3" değerini (2×3px) telafi eder;
   net boşluk tam 3mm olur. Kural, alanın hücrenin TEK içeriği olduğu durumda geçerlidir.
   Kopyalama ikonu gibi ikinci bir eleman varsa alan doğal genişliğinde kalır. */
table.dataTable tbody td > input[type="text"]:only-child,
table.dataTable tbody td > input[type="search"]:only-child,
table.dataTable tbody td > textarea:only-child,
table.dataTable tbody td > .chosen-container:only-child{
  width: calc(100% - 6mm + 6px) !important; box-sizing: border-box; display: inline-block;
}
```

Checkbox ve radio bu kuralın dışındadır — doğal boyutlarında, ortalanmış kalır.
Sütun daraldığında alan da daralır, genişlediğinde genişler.



### 9.12 İlk sütun (checkbox) ve genişliği

**ZORUNLU DAVRANIŞ:** Bir datatable eklenirken kullanıcıya sorulur: **"İlk sütun checkbox olsun mu?"**

| Durum | Sütun genişliği |
|---|---|
| Sadece checkbox var | **25px** |
| Tabloda **ilk satır ekleme** özelliği var (ilk `<tr>` yeni kayıt satırı, ilk hücrede **Ekle** butonu) | **Ekle butonunun genişliği kadar** — sabit 25px verilmez |

```html
<!-- sadece checkbox -->
<th class="noVis noDown nowrap sorting_disabled" align="center"
    style="margin:5px;padding:10px;width:25px" rowspan="1" colspan="1"
    data-column-index="0" aria-label=""><input type="checkbox" class="itblack" name="toggleCB"></th>
```
```css
/* width:1% + min-width tekniği: sütun içeriği kadar daralır, boş alan içerik
   sütunlarına dağılır — checkbox sütunu geniş tablolarda şişmez. */
table.dataTable thead th.sorting_disabled,
table.dataTable:not(.has-add-row) tbody td:first-child{
  width:1% !important; min-width:25px; box-sizing:border-box; white-space:nowrap;
}
/* İlk satır ekleme varsa sütun EKLE BUTONUNUN genişliği kadar olur */
table.dataTable.has-add-row thead th.sorting_disabled,
table.dataTable.has-add-row tbody td:first-child{
  width:1% !important; min-width:0 !important; white-space:nowrap;
}
/* checkbox'ın varsayılan margin'i sütunu şişirir; sıfırlanır ki sütun tam 25px olsun */
table.dataTable thead th.sorting_disabled input[type="checkbox"],
table.dataTable tbody td:first-child input[type="checkbox"]{ margin:0; vertical-align:middle; }
```


### 9.13 Hücre içeriği hizası (tbody)

Datatable satırlarındaki değerlerin yerleşimi **içerik tipine göre** belirlenir:

| İçerik | Hiza |
|---|---|
| **DECIMAL** (ondalıklı sayısal — miktar, birim fiyat, tutar, satır toplamı…) | **SAĞA YASLI** |
| Decimal olmayan her şey (metin, tarih, kod, statü, checkbox, buton, ikon, tam sayı sayaç…) | **ORTALI** |

> Dikkat: tam sayı olması tek başına sağa yaslama sebebi değildir. "Ticari Sicil Numarası", "Vergi Numarası", "Satır No" gibi alanlar sayısal görünse de decimal değildir → **ortalı**.

```html
<!-- decimal -->
<td nowrap="" class="quantity__tr input-number text-right"><input class="onlyFloating config itblack requiredBg" size="8" value="1.00"></td>
<td nowrap="" class="detResultLine__tr text-right">36.73</td>

<!-- decimal olmayan -->
<td nowrap="" align="center">Ağu 28, 2026</td>
<td nowrap="" align="center">Onay Bekliyor</td>
```
```css
/* yalnızca tbody; thead sütun İSİMLERİ bu kuraldan etkilenmez, daima ortalı kalır */
table.dataTable tbody td{ text-align:center; }
table.dataTable tbody td.text-right,
table.dataTable tbody td.dt-right,
table.dataTable tbody td.input-number,
table.dataTable tbody td.decimal{ text-align:right; }
table.dataTable tbody td.text-right input,
table.dataTable tbody td.dt-right input,
table.dataTable tbody td.input-number input,
table.dataTable tbody td.decimal input{ text-align:right; }
```
Decimal input'lar ayrıca `class="irblack"` / `onlyFloating` ile de sağa dayalıdır (bkz. §4.4).

### 9.11 Filtre kutuları daima çalışır durumda olmalıdır

Üretilen her datatable'da — statik önizleme/HTML örneği dahil — `#filterrow` içindeki sütun filtre kutuları ve üstteki `dataTables_filter` "Bul" kutusu **gerçekten filtreleme yapmalıdır**; dekoratif bırakılmaz.

Statik HTML'de basit bir JS bağlanır: her filtre kutusunun `input` olayında, bağlı olduğu sütun indeksindeki hücre metni küçük harfe çevrilip aranan değeri içermiyorsa `tr` gizlenir. Tüm sütun filtreleri **AND** mantığıyla birleşir; "Bul" kutusu satırın **tamamında** arar. Filtreleme sonrası:
- `dataTables_info` metni görünen satır sayısına göre güncellenir
- Satır bantları (`tr.odd` / `tr.even`) görünür satırlara göre yeniden atanır

Gerçek ekranlarda bu işi DataTables'ın kendi kolon filtresi yapar; markup ve sınıflar aynı kalır.

---

## 10. SEARCH HELP (Arama Yardımı)

İkon her zaman `view.gif`; alanın hemen sağında:
```html
<input mcselect="Y" class="itblack" readonly data-coltype="inputColumn" type="text" size="12" id="X">
<a href="#" id="Popup_X"><img src="/vedi/images/view.gif" border="0"></a>
```

### ZORUNLU DAVRANIŞ
Search help içeren bir tasarım yapmadan **önce kullanıcıya İKİ soru sorulur** ve cevabına göre ilerlenir:
1. Alan **SINGLE SELECT** mi **MULTI SELECT** mi olacak?
2. Tıklandığında **TAM SEARCHTABLE** formu mu, **BASİT POPUP** mu açılacak?

### 10.1 TAM FORM (searchTable.jsp) — POPUP olarak açılır

**Popup asla tam sayfa açılmaz.** Boyut sayfanın yaklaşık **1/5'i** kadardır ve **resize edilebilir**; konumu **tıklanan `view.gif` ikonuna göre** ayarlanır (ekranın ortasına değil).

```css
.vsrm-modal{ position:fixed; z-index:5000; display:none; overflow:auto; resize:both;
  min-width:320px; min-height:200px; border:1px solid #7F7F7F; background:#FFF;
  box-shadow:0 4px 18px rgba(0,0,0,.25); }
/* height değil MAX-HEIGHT — içerik azsa popup küçülür, altta boşluk kalmaz */
.vsrm-modal.sh-modal{ width:45vw; height:auto; max-height:45vh; }
.vsrm-modal .dt-tb-wrp{ min-height:0 !important; }
.vsrm-modal .tableStickyHead{ max-height:38vh; }
.vsrm-modal .dataTables_wrapper{ border:0; padding:4px 6px 2px; width:100% !important; }
```
Popup kabuğu: üstte sürüklenebilir başlık şeridi (`vsrm-modal-head`, zemin #CCCCCC) + sağda "✕ Kapat".
Konumlama: ikonun `getBoundingClientRect()` değerine göre hemen altına yerleştirilir; ekran dışına taşarsa içeri çekilir.

İçerik: `<div id="page-wrp">` → `<div class="button-grp-wrp">` içinde `<button style="margin-right:20px;">Sadece Seçilenleri Göster</button>` ve `<button style="margin-left:20px;">Temizle</button>` → altında **standart datatable** bloğu (§9.2: başlık şeridi + Bul + 4 ikon + hap filtreler + bantsız beyaz satırlar + sayfalama).

Tablo: `<table id="table" class="fddgray display cell-border tableborder backtgra dataTable no-footer" width="100%">`. Kolonlar tipik olarak **Kod / Tanım**.
- **Multi select** ise: ilk sütunda `<input type="checkbox" class="itblack" id="selectAllId">` + satırlarda checkbox
- **Single select** ise: checkbox sütunu **olmaz**, satıra tıklanarak seçilir ve form kapanır

### 10.2 BASİT POPUP (mcselect)
İlgili hücrenin/alanın hemen **ALTINDA** açılır. İki parçadır:

**Üst şerit:**
```html
<div class="backtblue2 mcselect_header" style="border:1px solid black;position:absolute;z-index:2000">
  <table style="font-size:10px" class="fddgray" width="100%"><tr>
    <td align="right" nowrap><b>Detay Filtresi:</b></td>
    <td align="left"><input type="text" class="itblack" size="15"></td>
    <td align="left"><input type="checkbox"></td>
    <td nowrap align="left"> Yalnızca şeçilenleri göster</td>
    <td align="left"><a href="#"><i class="fa fa-trash"></i></a></td>
    <td nowrap align="left">Clear</td>
    <td align="right"><input type="button" class="ibblack" name="bClose" value="Kapat"></td>
  </tr></table>
</div>
```

**Gövde:**
```html
<div class="mcselect_body" style="overflow:auto;max-height:250px;max-width:1000px;background:#fff;position:absolute;z-index:2000;border:1px solid">
  <table class="fddgray" width="100%" border="0" cellspacing="0" cellpadding="3">
    <thead><tr class="backtgra">
      <th style="text-align:left;padding-right:10px"><input type="checkbox"></th>
      <th nowrap style="text-align:left;padding-right:10px">Kod</th>
      <th nowrap style="text-align:left;padding-right:10px">Tanım</th>
    </tr></thead>
    <tbody>
      <tr class="fddgray"><td width="5%"><input type="checkbox" class="itblack" name="ids" value="DB"></td><td>DB</td><td>Yapay SA siparisi</td></tr>
    </tbody>
  </table>
</div>
```

---

## 11. WIZARD FORM

### 11.1 Header sırası

**(1) Özet bandı**
```html
<table class="fddgray table-info-top" width="100%" border="0" cellspacing="0" cellpadding="3">
  <tr>
    <td nowrap>Şirket Kodu <span>Örnek Firma</span></td>
    <td nowrap>Referans Numarası <span>1600000095</span></td>
    <td nowrap>Talep Toplam Bedeli <span>84,546.31 - TRY<br></span></td>
    <td nowrap>Belge Tipi <span>Katalog SAT</span></td>
    <td nowrap>Talep Statüsü <span title=""></span></td>
    <td nowrap>Onay Durumu <span title=""></span></td>
  </tr>
</table>
```
`.table-info-top` → zemin `rgba(128,128,128,.12)`, bold; `.table-info-top span` → `padding-left:13px; color:#EA5460; font-size:11px`

**(2) Adım çubuğu**
```html
<div class="mt-element-step flat">
  <a class="stpbtn button button-icon-only default pull-left disabled"><i class="fa fa-reply"></i></a>
  <a id="aForward" class="stpbtn button button-icon-only default pull-left "><i id="iForward" class="fa fa-share"></i></a>
  <div class="row step-thin">
    <div class="col-xs-4 myStep bg-grey mt-step-col active ">
      <div class="mt-step-number bg-white font-grey">1</div>
      <div class="mt-step-title font-grey-cascade">TALEP BAŞLIK TANIMI</div>
      <div class="mt-step-content font-grey-cascade">Talep Başlık Bilgileri</div>
    </div>
    <!-- 2: ÜRÜN SEÇIMI / Ürün ve Hizmet Seçimi -->
    <!-- 3: ONAY / Tamamla ve Onaya Gönder -->
  </div>
</div>
```
Durum renkleri: `bg-grey` **#E5E5E5** (boş) | `active` **#87A6CC** | `filled` **#5BD75B** | `done` **#26C281** | `error` **#E7505A**. `.myStep` width **469px**.

**(3) Kabuk + aksiyon butonları**
`<table class="borderAgray">` → `<table class="borderAgray and fddgray">` → `<table class="borderAdgray and backgray">`; içinde:
```html
<div class="button-grp-wrp">
  <button type="button" class="button button-vedi warning">TEST RUN <i class="fa fa-reply"></i></button>
  <button type="button" class="button button-vedi warning"> Kapat <i class="fa fa-reply"></i></button>
</div>
```

**(4) headerTable — ÜÇ SÜTUNLUDUR**
```html
<div id="fragmentmain">
<div style="width:100%" id="tablecontainer" class="fddgray">
<table id="headerTable" class="fddgray and tableborder and borderAdgray" style="width:100%" border="0" cellspacing="0" cellpadding="3" bordercolor="#AAAAAA">
  <tr>
    <td valign="top">…SÜTUN 1…</td>
    <td valign="top">…SÜTUN 2…</td>
    <td valign="top" class="addressBlockTemp_tr">…SÜTUN 3 (ADRES BLOĞU)…</td>
  </tr>
</table>
</div>
</div>
```
Her sütun içinde `<table class="fddgray and tableborder" cellspacing="3" cellpadding="3" bordercolor="#AAAAAA">` ve her alan `<tr class="{alanAdi}_tr"><td align="right">Etiket</td><td>alan</td></tr>` biçimindedir.

**SÜTUN 1 alanları:**
| `<tr>` sınıfı | Etiket | Alan |
|---|---|---|
| `vendorId_tr` | Ana Firma | `<input readonly class="is150 isDisabled custom-field">` |
| `vendorCompany_tr` | Şirket Kodu | chosen **requiredBg** |
| `docTypeCategory_tr` | Belge Türü Kategorisi | chosen |
| `documentType_tr` | Belge Türü | chosen **requiredBg** |
| — | Yaratma Tarihi | düz metin "Ağu 28, 2026 14:34" |
| — | Talebi Oluşturan | `<input class="custom-field" disabled>` |
| `requestOwner_tr` | Talep Sahibi | chosen |
| `description_tr` | Tanım | `<textarea class="itblack requiredBg config" rows="3" cols="50">` |
| `procNote_tr` | Dahili Talep Notu | textarea + `img-internal-note` ikonu |
| `fileCountHeaderIn_tr` | Dahili Dosya | attachment ikonu, `litorigin="1"` |
| `fileCountHeaderEx_tr` | Harici Dosya | attachment ikonu, `litorigin="2"` |

**SÜTUN 2 alanları:**
| `<tr>` sınıfı | Etiket | Alan |
|---|---|---|
| `hiddenRefNumber_tr` | Referans Numarası | düz metin |
| `hiddenErpRefNumber_tr` | ERP Talep Numarası | düz metin |
| `headerField1_tr` | Sole İş Ortağı mi? | chosen |
| `headerField2_tr` | Şartname Gerekli mi? | chosen |
| `headerField3_tr` | Talep Başlık Alanı - 3 | chosen |
| `keyword_tr` | Anahtar Kelime | chosen |
| `redirectWarehouse_tr` | Depoya yönlendir | checkbox, `style="display:none"` |
| `isUrgent_tr` | Acil | checkbox |

**SÜTUN 3 — ADRES BLOĞU:**
```html
<td valign="top" class="addressBlockTemp_tr">
  <span class="itblack config configTab" name="addressBlockTemp" id="addressBlockTemp"></span>
  <table class="fddgray and tableborder" style="width:100%" border="0" cellspacing="3" cellpadding="3" bordercolor="#AAAAAA">
    <tr><td colspan="2">
      <table id="addressDetailsBlock" class="fddgray tableborder borderAdgray" style="width:100%" cellspacing="0" cellpadding="3">
        <tr><td>
          <button type="button" class="configBtnAddr button button-default button-circle button-sm btn-active-tab" style="width:154px"> Ana Firma Sevk Adresi </button>
        </td></tr>
        <tr class="spNoVis factoryId_tr"><td align="right">Fabrika</td><td>chosen requiredBg</td></tr>
        <tr class="spNoVis storeId_tr"><td align="right">Depo Yeri</td><td>chosen requiredBg</td></tr>
        <tr class="addressId_tr">
          <td align="right">Adres Adı</td>
          <td align="left">chosen requiredBg</td>
          <td><button type="button" class="button button-vedi success"> Ekle <i class="fa fa-plus"></i></button></td>
        </tr>
        <tr><td colspan="3"><hr></td></tr>
        <!-- aşağıdakilerin HEPSİ disabled -->
        <tr class="iAddress1_tr"><td align="right">Adres</td><td align="left" colspan="2"><textarea disabled class="config itblack" rows="2" cols="36"></textarea></td></tr>
        <tr class="iAddress2_tr"><td colspan="1"></td><td align="left" colspan="2"><textarea disabled class="config itblack" rows="2" cols="36"></textarea></td></tr>
        <tr class="iCity_tr"><td align="right">Şehir</td><td align="left"><input disabled class="config itblack"></td></tr>
        <tr class="iRegion_tr"><td align="right">Bölge</td><td align="left"><input disabled class="config itblack"></td></tr>
        <tr class="iRegionCode_tr"><td align="right">Bölge Kodu</td><td align="left"><input disabled class="config itblack"></td></tr>
        <tr class="iZip_tr"><td align="right">Posta Kodu</td><td align="left"><input disabled class="config itblack"></td></tr>
        <tr class="iCountry_tr"><td align="right">Ülke</td><td align="left"><input disabled class="config itblack"></td></tr>
        <tr class="iPhone_tr"><td align="right">Telefon</td><td align="left"><input disabled class="config itblack"></td></tr>
        <tr class="iFax_tr"><td align="right">Faks</td><td align="left"><input disabled class="config itblack"></td></tr>
      </table>
    </td></tr>
  </table>
</td>
```
`.btn-active-tab` → zemin **#547195**, beyaz yazı. `.button-sm` → `padding:5px 10px; font-size:12px; line-height:1.5`

### 11.2 Detay / Ürünler sekmesi
Aynı özet bandı + adım çubuğu, altında server-side DataTable (`detailTable_N`, bkz. §9.4).
Satır seçilince alta jQuery UI sekmeli panel açılır:
```html
<ul class="ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all">
  <li class="tbFrag1_tr ui-state-default ui-corner-top"><a id="tbFrag1" class="config configTab" href="#fragment1"><span>Talep Detay Bilgisi</span></a></li>
  <li class="tbFrag2_tr …"><a id="tbFrag2" …><span>Hesap &amp; Dağıtım Bilgileri</span></a></li>
  <li class="tbFrag3_tr …"><a id="tbFrag3" …><span>Ana Firma Sevk Adresi</span></a></li>
  <li class="tbFrag4_tr …"><a id="tbFrag4" …><span>Tedarik Kaynağı Önerileri</span></a></li>
  <li class="tbFrag5_tr …"><a id="tbFrag5" …><span>Notlar</span></a></li>
  <li class="tbFrag6_tr …"><a id="tbFrag6" …><span>Metinler</span></a></li>
</ul>
<div id="fragmentN" class="ui-tabs-panel ui-widget-content ui-corner-bottom">…</div>
```

---

## 12. DAHİLİ / HARİCİ NOT ALANLARI

"Notlar" sekmesinin en üstünde **Güncelle** butonu (`button button-vedi warning` + `fa-edit`), altında:

```html
<tr class="internalLineNote__tr">
  <td align="right" valign="top"><b>Dahili Satır Notu</b></td>
  <td align="left">
    <textarea class="config itblack" rows="5" cols="50" id="internalLineNote_1" name="internalLineNote_1"></textarea>
    <span><a title="Dahili" href="#"><img class="img-internal-note" src="/vedi/images/note.jpg" border="0"></a></span>
  </td>
</tr>
<tr class="externalLineNote__tr">
  <td align="right" valign="top"><b>Harici Satır Notu</b></td>
  <td align="left">
    <textarea class="config itblack" rows="5" cols="50" id="externalLineNote_1" name="externalLineNote_1"></textarea>
    <span><a title="Harici" href="#"><img src="/vedi/images/note.jpg" border="0"></a></span>
  </td>
</tr>
```
**Dahili** notta ikona `class="img-internal-note"` verilir (mavimsi). **Harici** notta sınıf verilmez (orijinal renk).

Başlık formunda tekil not alanı: `<tr class="procNote_tr">` → "Dahili Talep Notu" + `<textarea class="itblack config" rows="3" cols="50">` + `img-internal-note` ikonu.

---

## 13. DOSYA EKLEME

### 13.1 İkon
Dosya eklenecek her yerde:
```html
<a type="file" littype="REQ_HEADER" littypeid="0" litsubtype="" litorigin="1" litspid="0"
   litqueryforvd="N" litusespid="N" class="config" id="fileCountHeaderIn_a" name="fileCountHeaderIn_a" href="#">
  <img src="/vedi/images/attachmentList.gif" border="0"><b>(<span id="fileCountHeaderIn">0</span>)</b>
</a>
```
`litorigin="1"` → **DAHİLİ** (Internal) | `litorigin="2"` → **HARİCİ** (External)
Form/başlık tablosunda `<tr class="fileCountHeaderIn_tr">` → "Dahili Dosya", `fileCountHeaderEx_tr` → "Harici Dosya".
Datatable satırında `<td nowrap class="dt-center">` içine aynı ikon + `(sayı)`.

### 13.2 Açılan form
**(A) Üst blok — Dosyalar**
`<table id="upperTable" class="borderAgray" width="90%" align="center">` → `<table class="borderAdgray and backgray">` → başlık şeridi `<table class="backtgra and fddgray"><td>Dosyalar</td>` → altında yüklenmiş dosya listesi (boşsa `<table class="fdblue" width="90%" align="center"><td align="center">Dosya yok</td>`).

**(B) Alt blok — Dosya Yükle**
`<form name="fAddAttachment" method="post" enctype="multipart/form-data">` → `<table class="borderAgray" width="90%" align="center">` → `<table class="borderAdgray and backgray">` → başlık şeridi `<table class="backtgra and fddgray"><td>Dosya Yükle</td>` → ardından `<table class="tableborder and fddgray" width="90%" bordercolor="#AAAAAA">` satırları.

Her alan **kendi mini tablosundadır**:
```html
<table class="borderAdgray" width="100%" border="0" cellspacing="1" cellpadding="1">
  <tr><td nowrap class="backtblue2" align="center">Etiket</td></tr>
  <tr><td nowrap class="backwhite and fddgray" align="center">değer / alan</td></tr>
</table>
```

Standart alanlar:
- **1. satır:** Sektör (select chosen) | İş Ortağı | Tip | Alt Grup (select chosen)
- **2. satır:** Tarih (düz metin) | Geçerlilik Başlangıcı (`<input readonly class="idblack" size="12">`) | Geçerlilik Sonu (aynı)
- **3. satır:** Tanım (`<textarea class="itblack" cols="45" rows="3">`)

En altta:
```html
<td align="center" class="itblack">
  <input class="ibblack" type="file" size="50" name="fileToUpload" multiple>
  <input class="ibblack" type="button" value="Dosya Yükle">
  <input class="ibblack" type="button" value="Kapat">
</td>
```

---

## 14. HIZLI KONTROL LİSTESİ

Yeni bir VSRM ekranı tasarlarken:

0. [ ] **Tetikleyici cümle gerçekten geçti mi?** Geçmediyse bu listedeki hiçbir madde uygulanmaz. Geçtiyse bu doküman okundu mu, başka projeden hiçbir şey taşınmadı mı?
1. [ ] Ana sayfa/menü gerekiyorsa `exVSRM_anasayfa_bos.html` kabuğu kullanıldı mı?
2. [ ] Tüm fontlar Arial 11px mi? Hiyerarşi zemin rengiyle mi kuruldu?
3. [ ] Combobox'lar chosen yapısında mı (23px, radius 5px, #AAA çerçeve, gradient)?
4. [ ] Zorunlu alanlar `requiredBg` (mistyrose) mi?
5. [ ] Butonlar doğru renk sınıflarında mı (Ekle=success, Sil=danger, Güncelle=warning, Bul=düz, Görüntüle=info)?
6. [ ] Datatable filtre kutuları radius 10px, height 19px, ortalı mı?
7. [ ] Datatable `#page-wrp float:left` ile sola dayalı ve `95vw` fit-to-page mi? Altta yatay scroll var mı?
8. [ ] Başlıklar `tableStickyHead` ile yapışkan mı? Satırlar `tr.odd` #F0F4FB / `tr.even` #FFFFFF mi?
8b. [ ] Datatable ikonları **4 tane** (download/filter/cog/cogs), FontAwesome ve grid'in sağ üst KÖŞESİNE DAYALI mı (kolon padding'i sıfırlandı mı)?
8c. [ ] Kullanıcıya "İşlem Seçiniz yapısı istiyor musunuz?" soruldu mu? (§9.7)
9. [ ] Tarih alanları `idblack` + "Ağu 28, 2026" formatında mı?
10. [ ] Search help varsa kullanıcıya single/multi ve tam form/basit popup soruldu mu?
11. [ ] İkonlar `/vedi/images` altındaki gerçek dosyalar mı (FontAwesome taklidi değil)?
12. [ ] Sayfa altında ITG Ltd. footer'ı var mı?
13. [ ] Kullanıcının talep ettiği genişletme varsa mevcut tokenlar üzerine mi kuruldu ve kullanıcıya belirtildi mi? (§15)
14. [ ] Kullanıcıya **"Bu ekranda log kaydı tutulsun mu?"** soruldu mu? Tutulacaksa Log sütunu **en sonda** mı, ikon renkleri (mavi/gri) doğru mu? (§16)
15. [ ] Satır içi alanların ve filtre kutularının sütun ızgarasından **3'er mm** boşluğu var mı? (§9.10)
16. [ ] Başlık satırı **auto height** mi (tek satıra sığıyorsa tek satır)? Sütun isimleri **ortalı** mı?
17. [ ] Sayfadaki filtre etiketleri **sola dayalı** mı? Satır çizgileri `#E4E9EF` mi?
18. [ ] Sıralama okları sütun isminin **sağında ve aynı satırda** mı? Metinle çakışıyor mu?
19. [ ] sfContainer bandı **tek satır** mı (toggle + buton + Filtre Seçin yan yana)?
20. [ ] Filtre alanları sol üstten başlayıp **blok başına max 4 satır**, sağa doğru mu?
21. [ ] searchHelp popup'ı **1/5 boyut**, tıklanan ikona göre konumlu ve **resize edilebilir** mi?
22. [ ] Log popup'ı **1/4 boyut**, **ortalı** ve resize edilebilir mi? Altta boşluk var mı?
23. [ ] Filtre kutuları **gerçekten filtreliyor** mu? (§9.11)
24. [ ] Kullanıcıya **"İlk sütun checkbox olsun mu?"** soruldu mu? Genişlik doğru mu (checkbox 25px / Ekle butonu kadar)? (§9.12)
25. [ ] Satırlarda **decimal alanlar sağa yaslı**, decimal olmayan her şey **ortalı** mı? (§9.13)
26. [ ] Her combobox'ın **ilk seçeneği "Seçiniz"** mi? Yeni kayıt satırındaki combobox'ın değeri **"Seçiniz"** mi? (§4.1)

---

## 15. BİLEŞEN GENİŞLETME

Bu kütüphane bir **taban**, duvar değil. İki durum kesin olarak ayrılır:

| Durum | Ne yapılır |
|---|---|
| Claude'un **kendi kafasına göre** bileşen, renk veya stil üretmesi | **Yasak** |
| **Kullanıcının açıkça talep ettiği** ekleme veya değişiklik | **Yapılır** |

Kullanıcı şunları isteyebilir ve hepsi meşrudur:
- Datatable'a yeni sütun veya sütun tipi
- Forma yeni alan
- Ek buton veya buton varyantı
- Mevcut bir bileşenin farklı bir düzeni
- Kütüphanede hiç bulunmayan yeni bir bileşen

Bu taleplere **"kütüphanede yok" denilerek karşı çıkılmaz.**

### Genişletme yaparken uyulacak kurallar

1. **Mevcut tokenlar ve sınıf adları üzerine kurulur.** Yeni CSS sınıfı uydurulmaz. `itblack`, `fddgray`, `idblack`, `irblack`, `ibblack`, `button-vedi`, `requiredBg`, `backtgra`, `borderAdgray`, `tableborder` gibi §2 ve §3'teki mevcut sınıflar kullanılır.

2. **Yeni bir alan tipi isteniyorsa en yakın mevcut VSRM alan tipi örnek alınır.** Örnek: "yüzde alanı" istenirse §4.4'teki sayısal alan kalıbı (`onlyFloating config itblack` + `text-center input-number` hücre sınıfı) temel alınır.

3. **Görünümü belirsizse önce sorulur.** Kütüphanede hiç karşılığı olmayan ve nasıl görüneceği tarif edilmemiş bir bileşen isteniyorsa tahmin edilmez; kullanıcıya sorulur.

4. **Yapılan genişletme kullanıcıya belirtilir.** Tek cümle yeterlidir: *"Bu kısım kütüphanede yoktu, mevcut sayısal alan kalıbına göre kurdum."*

5. **Kalıcılaştırma teklif edilir.** Kullanıcı genişletmenin bundan sonra standart olmasını isterse, hafızaya kazınması ve bu dokümana + `vsrm_bilesen_kutuphanesi.html` dosyasına eklenmesi gerektiği hatırlatılır.

---

## 16. LOG (Değişiklik Kaydı)

> Kaynak: `userAdministrationLog.jsp`

**ZORUNLU DAVRANIŞ:** Her tasarımda kullanıcıya **"Bu ekranda log kaydı tutulsun mu?"** diye sorulur.

### 16.1 Log sütunu

Log tutulacaksa datatable'ın **EN SONDAKİ sütunu** daima "Log" sütunudur.

```html
<!-- başlık -->
<th nowrap="" class="sorting" tabindex="0" aria-controls="{id}" data-column-index="N"
    aria-label="Log: artan sütun sıralamasını aktifleştir" style="width:23px">Log</th>

<!-- satırda LOG VARSA — soft mavi, tıklanabilir -->
<td nowrap="" align="center" title="Log kayıtlarını göster">
  <a class="logPopupBtn"><img src="/vedi/images/log.png" class="img-log" border="0"></a>
</td>

<!-- satırda LOG YOKSA — gri, tıklanamaz -->
<td nowrap="" align="center" title="Log kaydı yok">
  <img src="/vedi/images/log.png" class="img-log-empty" border="0">
</td>
```

Temel görsel **altın/amber tonlu 13×17px doküman ikonudur**. Renklendirme `note.jpg`'deki gibi CSS filter ile yapılır:
```css
.img-log      { filter: hue-rotate(165deg) saturate(.55) brightness(.95); }  /* LOG VAR  → soft mavi */
.img-log-empty{ filter: grayscale(1) brightness(1.25); }                     /* LOG YOK  → gri */
```

### 16.2 Log popup

İkona tıklanınca açılan popup **bir datatable'dır ve klasik VSRM datatable yapısındadır**: sola dayalı, fit-to-page, `tableStickyHead` yapışkan başlık, `#filterrow` + başlık satırı, **4 ikon sağ üst köşede**, altta info / paginate / length.

Popup'ın üstünde başlık şeridi bulunur, dış kabuk iç içe tablolardır:
```html
<table class="borderAgray" width="100%" cellspacing="0" cellpadding="1"><tr><td>
 <table class="borderAgray and fddgray" width="100%" cellspacing="0" cellpadding="1"><tr><td align="center">
  <table class="borderAdgray and backgray" width="100%" cellspacing="0" cellpadding="1"><tr><td align="center">
   <table class="backtgra and fddgray" width="100%" cellspacing="0" cellpadding="3"><tr><td>&nbsp;</td></tr></table>
   <table class="backNtgra and fddgray" width="100%" cellspacing="0" cellpadding="3" style="margin-bottom:2px">
     <tr><td>Listeleme</td></tr>
   </table>
   <div id="page-wrp" style="float:left">
     <div id="logTable_wrapper" class="dataTables_wrapper no-footer">… (§9 iskeleti) …</div>
   </div>
  </td></tr></table>
 </td></tr></table>
</td></tr></table>
```

**Log tablosu sütunları sabittir:**

| Değişiklik Yapan | Değişiklik Tarihi | Alan Adı | Eski Değer | Yeni Değer |
|---|---|---|---|---|

> "Kullanıcı" sütunu **kaldırılmıştır** — log zaten tek bir satıra ait olduğu için gereksizdir.

Tablo, **diğer datatable'larla aynı sınıf ve attribute setini kullanır**:
```html
<table id="{id}" class="fddgray display cell-border tableborder backtgra dataTable no-footer"
       style="width:100%" border="0" cellspacing="2" cellpadding="3" role="grid">
```
> Kaynak JSP'de bu tablo `border="1" bordercolor="#AAAAAA"` ile yazılmıştır; bu, hücre çizgilerini standarttan koyu yapar. Log popup'ı da klasik VSRM datatable'ı olduğu için yukarıdaki standart set kullanılır.
Filtre satırı hücreleri `<th class="dt-filter">`; **checkbox sütunu yoktur.**
Boş durumda: `<tr class="odd"><td valign="top" colspan="5" class="dataTables_empty">Tabloda herhangi bir veri mevcut değil</td></tr>`

**Popup boyutu ve konumu:** Log popup'ı sayfanın yaklaşık **1/4'ü** kadardır, **ekranın ortasında** açılır ve **resize edilebilir**. Altta gereksiz boşluk bırakmaz.
```css
.vsrm-modal.log-modal{ width:50vw; height:auto; max-height:50vh; top:25vh; left:25vw; }
.vsrm-modal #page-wrp{ width:100%; max-width:100%; float:left; }
.vsrm-modal .dataTables_wrapper{ width:100% !important; max-width:100%; }
```

Log verisi, alanlardaki `data-log-old-value` / `data-log-old-text` / `data-log-field` / `data-log-line-no` / `data-log-rqd-id` attribute'larından üretilir (bkz. §4).

# Ekran desenleri

Şablonlarda kullanılan vSRM ekran düzenleri. Uyarlarken bu yapıları koru; görseller [referans](referans) klasöründedir.

Bakiye hesapları, `x/y belge` sayımı, taslak ayırma ve onay davranışı şablonun kodundadır. Uyarlarken bunları yeniden yazma.

## Sayfa kabuğu

Yukarıdan aşağı sırayla:

1. **Üst alan:** Solda vSRM logosu, ortada başlık ve alt başlık, sağda `Görünüm` seçimi (Ana firma / Tedarikçi).
2. **Menü çubuğu:** Açılır menüler.
3. **Araç satırı:** Solda küçük yuvarlak düğmeler (`JSON yedek indir`, `Yedek yükle`, `Başlangıç örnekleri`, `Rehber tur`), sağda simülasyon uyarısı.
4. **Sekme satırı.**
5. **Bölüm bandı:** Ekran adı.
6. **`Arama Filtreleri` bandı:** Düğme ve `Filtre Seçin` listesi, altında filtre alanları ve `Bul`.
7. **Tablo.** Üstte `Bul` kutusu, sağda dört ikon, başlığın üstünde kolon filtre kutuları.

## ASN ana ekranı: Sevkiyat Hazırlık ve Onay

Görsel: [asn-sevkiyat-izgarasi.png](referans/asn-sevkiyat-izgarasi.png)

Ekran özet tablo değil, **sipariş kalemi ızgarasıdır**. Her satır bir sipariş kalemidir ve kalite kontrolü satırın içinden açılır.

**Filtreler:** Satınalma Sorumlusu, Ürün Numarası, SA Emir No, Tarih aralığı, Ürün Tanımı, Satır No, Bakiyesi 0'dan büyük, Ürün Alt Grubu, Tedarikçi Ürün No, Planlanan statüdeki siparişleri de göster, İşemri No.

**Kolonlar, bu sırayla:** seçim kutusu, SA Emir Numaraları, Satır, MTO, İşemri No, Operasyon No, İskele - Kapı, Tedarikçi Ürün No, Ürün Numarası, Ürün Tanımı, Teknik Resim, Ürün Revizyonu, Termin Tarihi, ÖB, Via Kodu, Talep Edilen Mik, Red Mik, Toplam Gönderilen Mik., Toplam Paketlenen Mik., Sevkiyat Bazlı Bakiye, Tesellüm Bazlı Bakiye, Kalite kontrol gereksinimi (mercek), Kalite süreçlerine göre sevk edilebilir miktar, İşlem Mik., Paket Tipi, Paketin İçindeki Miktar, İşlem Paket Sayısı, vSRM seri/lot no.

**Tablo altı:** Yeni İrsaliye Numarası, Paket Oluştur, Karma Paket Oluştur, Mevcut İrsaliye Numarası, Paket Ekle, Karma Paket Ekle, Karma Pakete Ekle. Paket tablosunda Güncelle, Sil, Gönder, Etiket Yazdır, Sevkiyat Detayları.

**Akış:** `İşlem Mik.` tıklanır → Seri/Lot penceresi açılır → uygun kayıtlar seçilir → `Seçilenleri Ekle` toplamı satıra yazar → paket ve irsaliye oluşturulur → gönderilir.

## Seri / Lot penceresi

Görsel: [asn-seri-lot-penceresi.png](referans/asn-seri-lot-penceresi.png)

Sayfa üstünde geniş pencere; arka plan karartılır.

- **Başlık bandı:** `Seri / Lot · tedarikçi · sipariş / kalem · ürün`, sağda `Küçült` ve `Kapat`.
- **Özet satırı:** Sipariş miktarı, Oluşturulan, Oluşturulabilecek, sayaçlar, `İşlem miktarı`, `Bağlı sevkiyatlar`.
- **Eylemler:** `Seçilenleri Ekle`, hata metni kırmızı, `Gereksinimi olmayan kalite türlerini de göster`, `Güncelle`, `Sil`, `Seri/Lot No Ekle`.
- **Kolonlar:** İşlem, Ürün no, Ürün revizyonu, vSRM seri/lot no, Üretici seri/lot no, Seçilen miktar, Heat Lot No, Miktar, Ölçü birimi, Sevke uygunluk, Kalite süreçlerine göre uygun miktar, Toplam Gönderilen Mik., Kalite süreçlerine göre sevk edilebilir miktar, Toplam Paketlenen Mik., ardından **her kalite türü için bir kolon**.
- **Kalite kolonu:** İki satırlı hücre. Üstte yuvarlak düğme `GIF · 1/1 belge`, altında `uygun / toplam` miktarı. Düğme ilgili belgeleri açar.
- **Sevke uygunluk:** Durum hapı (`Sevke uygun`, `Miktar ayrılmış`). Uygun olmayan satırın seçim kutusu pasiftir.
- **Alt not:** Taslak ve iptal davranışını anlatan tek satır.

## Uygunluk matrisi

Görsel: [asn-uygunluk-matrisi.png](referans/asn-uygunluk-matrisi.png)

Kalite türü, başlık statüsü ya da karar ile sevk etkisini listeler. Etkiler: `İzin`, `Engel`, `Satıra bak`, `Etkisiz`, `Teyit bekliyor`.

## Bakım ve liste ekranları

Görsel: [seri-lot-bakim.png](referans/seri-lot-bakim.png)

Tablo seçilir, filtreler yalnızca `Bul` ile uygulanır, `Temizle` sıfırlar, Enter `Bul` çalıştırır. Kolon filtreleri ve dört ikon kalır. Tablo sayfayı genişletmez, kendi alanında yatay kayar.

## Durum dili

Metinde "gerçek", "canlı" veya "entegre" deme. Ekran simülasyondur ve bunu araç satırında söyler.

Bilinmeyen değeri uydurma. Karar veya kural bilinmiyorsa `Teyit bekliyor` göster. Görev metni boş kalmasını söylüyorsa, örneğin henüz tetikleyicisi olmayan tarih alanlarında, hücreyi boş bırak.

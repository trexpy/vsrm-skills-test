# Ekran üretim rehberi

Danışmanın yeni bir ekran istediğinde veya şablon uyarlarken geçerlidir. Görsel değerler için [profiller.md](profiller.md) ve [tasarim-kurallari.md](tasarim-kurallari.md) esastır; bu dosya onlarla çelişirse o dosyalar geçerlidir.

## Çelişkide öncelik

Sıra: uyarladığın ekranın mevcut değeri, [profiller.md](profiller.md), bu rehber, [bilesenler-v5.md](bilesenler-v5.md). Bileşen dosyası tarihsel teknik referanstır. Oradaki "ZORUNLU DAVRANIŞ" soruları, 19px filtre, 1/5 popup ve yeni bileşen izni yukarıdaki dosyalarla çeliştiği yerde geçersizdir.

## Hibrit yaklaşım

1. En yakın mevcut vSRM ekranını veya şablonu bul. Sıfırdan başlama.
2. Eksik kalan yerleri `kurallar/` içindeki desen ve bileşenlerle tamamla.
3. Yeni bileşen icat etme, mevcut sınıf adlarını değiştirme.
4. Ekran akışındaki iş kuralını sessizce değiştirme. Değişiyorsa açık karar olarak yaz.
5. `sablonlar/` dosyalarını doğrudan düzenleme; kopyasında çalış.

Bu kural geçicidir. vSRM ürün reposu bağlanınca modül kuralları buraya eklenecek.

## Etkileşim kuralları

- V5 sınıf ve markup sözleşmelerini koru: `.dataTable`, `.tableStickyHead`, `.button.button-vedi`, `.itblack`, `.idblack`, `.irblack`, `.requiredBg` gibi sınıfları keyfi yeniden adlandırma.
- Yeni kayıt combobox başlangıcı `Seçiniz`; zorunlu alan mistyrose `#FFE4E1`, pasif alan açık gri. Etiket/alan ve eylem hizalarını birlikte kur.
- Tablo viewport içinde sola dayalı kalır; çok kolon sayfayı genişletmez, tablo alanı yatay kayar. Başlık ve filtre satırı sabitlenir; sticky ofsetini gerçek satır yüksekliğine göre ayarla.
- Başlıklar ortalı; decimal miktar/fiyat/tutar hücreleri sağa, diğer standart V5 hücreleri ortaya hizalanır. Sayısal görünen kodu decimal sayma.
- Üstte Bul, sağda dört standart ikon: `fa-download`, `fa-filter`, `fa-cog`, `fa-cogs`. Özgün ikonları kullan; emoji veya rastgele ikonla değiştirme. İkon grubu grid sağ kenarıyla en fazla 2px farkla hizalanır.
- Bul ve kolon filtreleri çalışır; kolon filtreleri AND birleşir. Sonuç adedi, bantlar, sayfalama ve sayfa boyutu filtrelenen sonuçla tutarlıdır. Dekoratif çalışan-gibi kontroller bırakma.
- Search help alanın yanındaki mercekten açılır; başlangıç yaklaşık 45vw ve en fazla 45vh, tetikleyiciye yakın, viewport içinde, taşınabilir/boyutlandırılabilir. Geniş matris için Büyüt/Küçült kullanılabilir. Single select satırla, multi select checkboxlarla çalışır.
- Detayı satırdan, belge numarasından veya durumdan erişilebilir kıl. Tooltip kısa açıklama içindir; kritik hata ve engel yalnız tooltip içine saklanmaz. Popup kapatılınca odağı tetikleyiciye geri ver, sayfayı zıplatma.

## İş davranışını tasarımla birlikte koru

- Ana firma ve tedarikçi görünümünü ayır; bir rolün göremediği veri grafikte, toplamda veya tooltipte sızmasın. Arayüzde gizleme gerçek sunucu yetkilendirmesi değildir.
- Kaynak kayıt, türetilmiş örnek ve simülasyon verisini ayır. Eksik ilişki, sıra, kabul veya hesap sonucunu uydurma. Bir müşteriye özel kalite kararlarını bütün müşterilerin kuralı haline getirme.
- Kaydet başarı mesajını ancak başarılı uygulamadan sonra göster. Geçersiz alanda neden ve düzeltme görünür olsun; iptal, taslak, kayıtlı ve kaydedilmemiş durumlarını ayır.
- Kontrolün görünür davranışıyla model doğrulaması aynı kurala dayanmalı. Demo/localStorage eşitlemesini gerçek JSP, SAP veya sunucu entegrasyonu diye sunma.


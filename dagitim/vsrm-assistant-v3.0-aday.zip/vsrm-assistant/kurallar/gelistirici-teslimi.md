# Geliştiriciye teslim

Danışman ekranı geliştiriciye aktarmak isterse bu biçimi kullan. Yalnızca istendiğinde üret.

## Klasör

- `BASLA.html`: Tek giriş sayfası. Ekranı ve görev metinlerini bağlar.
- Ekran HTML'i: Çalışan simülasyon.
- `<GOREV>_Jira_Aciklamasi.txt`: Göreve yapıştırılacak metin.
- `<GOREV>_Tablo_Alanlari_ve_Ornekler.txt`: Her tablo için alan listesi.
- `Gorseller/`: Numaralı ekran görüntüleri.

## Görev metni

```
<GOREV> — Başlık

Bir paragraf: ne oluşturulacak, neyi besleyecek.

MEVCUT KULLANILACAKLAR
Yeniden yapılmayacak mevcut kayıt ve ekranlar.

GELİŞTİRİLECEKLER
• Madde madde yeni iş.

<TABLO> ALANLARI — Alan | Tür | Örnek | Not

AÇIK KONULAR
Netleşmemiş kararlar. Doğrulanmayanı doğrulanmış gibi yazma.
```

## Görsel işaretleme

Görsellerin üstünde iki işaret kullan:

- **Mavi düz çerçeve:** Aynen kullan.
- **Turuncu kesikli çerçeve:** Geliştir veya bağla.

Her görselin başlığında şunlar yazar: `Ekran`, `Tablo`, `Geçiş`.

Görev anahtarını, tablo adını ve SAP referansını kendin üretme; danışmandan al.

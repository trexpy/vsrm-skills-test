# vSRM ekran tasarım kuralları

Bu kurallar şablon uyarlarken geçerlidir. Sırayla oku:

1. [profiller.md](profiller.md): Ölçülmüş görsel değerler.
2. [ekran-desenleri.md](ekran-desenleri.md): Ekran yapıları ve akışlar.
3. [referans](referans): Görsel hedef.
4. [canli-arayuz.md](canli-arayuz.md): Yalnızca canlı ihale gibi gerçek zamanlı ekranlarda.
5. [bilesenler-v5.md](bilesenler-v5.md) ve [bilesen-kutuphanesi-v5.html](bilesen-kutuphanesi-v5.html): Bileşen ayrıntısı, gerektiğinde.

Öncelik: uyarladığın şablonun mevcut değeri, sonra ölçülmüş değerler, sonra referans görsel.

## Kimlik

- ITG şirket, vSRM ürün kimliğidir. vSRM ile NVSRM'yi karıştırma.
- Paketteki özgün logoyu oranını koruyarak kullan.
- Standarttan sapma gerekiyorsa kısa biçimde belirt. Görev dışı yeniden tasarım yapma.

## Ortak kurallar

- V5 sınıf ve markup sözleşmelerini koru: `.dataTable`, `.tableStickyHead`, `.button.button-vedi`, `.itblack`, `.idblack`, `.irblack`, `.requiredBg` gibi sınıfları yeniden adlandırma.
- Yeni kayıt combobox başlangıcı `Seçiniz`; zorunlu alan mistyrose `#FFE4E1`, pasif alan açık gri.
- Tablo viewport içinde sola dayalı kalır; çok kolon sayfayı genişletmez, tablo alanı yatay kayar. Başlık ve filtre satırı sabitlenir.
- Başlıklar ortalı; decimal miktar, fiyat ve tutar hücreleri sağa, diğer standart hücreler ortaya hizalanır. Sayısal görünen kodu decimal sayma.
- Üstte Bul, sağda dört standart ikon: `fa-download`, `fa-filter`, `fa-cog`, `fa-cogs`. Özgün ikonları kullan. İkon grubu grid sağ kenarıyla en fazla 2px farkla hizalanır.
- Bul ve kolon filtreleri çalışır; kolon filtreleri AND birleşir. Sonuç adedi, bantlar ve sayfalama filtrelenen sonuçla tutarlıdır. Dekoratif çalışan-gibi kontroller bırakma.
- Tooltip kısa açıklama içindir; kritik hata ve engel yalnızca tooltip içine saklanmaz.

## İş davranışı

- Ana firma ve tedarikçi görünümünü ayır; bir rolün göremediği veri grafikte, toplamda veya tooltipte sızmasın. Arayüzde gizleme gerçek sunucu yetkilendirmesi değildir.
- Eksik ilişki, sıra, kabul veya hesap sonucunu uydurma.
- Kaydet başarı mesajını ancak başarılı uygulamadan sonra göster. Geçersiz alanda neden ve düzeltme görünür olsun.
- Demo veya localStorage davranışını gerçek JSP, SAP veya sunucu entegrasyonu diye sunma.
- Şablondaki kalite kuralları örnektir; bütün müşterilerin kuralı değildir.

## Teslim doğrulaması

- Çıktının görüntüsünü `araclar/ekran-goruntusu.ps1` ile al ve ilgili referans görselle yan yana karşılaştır: yazı boyutu, yoğunluk, kabuk katmanları, etiket ve alan hizası, tablo taşması, popup davranışı.
- Boş, dolu, filtreli ve hatalı durumları, rol farkını ve kaydet/iptal davranışını dene.
- Konsol hatalarını ve dış bağımlılıkları kontrol et.
- Yapılmayan kontrolü yapılmış gibi raporlama.

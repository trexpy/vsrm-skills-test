# Müşteri formu

`[ ]` yazan yerleri silip yanına kendi bilgini yaz. **Gerçek müşteri verisi yazma:** sipariş, tedarikçi, parça ve kişi bilgileri için temsili değerler kullan.

## Zorunlu

- Müşteri adı: [ ]
- Dosya adlarında kullanılacak kısa ad (Türkçe karaktersiz, örn. `orneksan`): [ ]
- Şablon (birini bırak): `asn-kalite` / `seri-lot-bakim` / `mm-fason`
- Görüşmede göstermek istediğin senaryo (bir-iki cümle): [ ]

## Marka (isteğe bağlı)

- Logo dosyası (bu klasöre koy, adını yaz): [ ]
- Ana renk (örn. `#004286`): [ ]

## Değişecek metinler

| Ekrandaki metin | Yeni metin |
| --- | --- |
| [ ] | [ ] |

## Örnek veri

- Ana firma kısa adı ve kodu: [ ]
- Üretim yeri, tedarikçi ve sipariş kodu biçimi (boş bırakırsan kurgusal üretilir): [ ]
- İki örnek tedarikçi adı: [ ]
- Ürün veya malzeme türleri (örn. "pompa gövdesi"): [ ]
- Ölçü birimleri: [ ]

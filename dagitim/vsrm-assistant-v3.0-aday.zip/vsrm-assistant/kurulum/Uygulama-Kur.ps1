# Danisman Merkezi parcalarini esitlenen OneDrive/SharePoint klasorunden kurar ve gunceller.
# Duzen: <KurulumYeri>\surumler\<surum>\ tam kurulum, <KurulumYeri>\aktif.txt etkin klasorun adi,
# <KurulumYeri>\ortak\<ad>-<ozet>\ agir parcalar. Surum klasorleri ortaga junction ile baglanir (yonetici gerekmez).
# Yeni surum ayri klasorde tamamen hazirlanir, aktif.txt en son ve atomik degisir; yarida kesilirse eski surum etkin kalir.
# Ozeti tutmayan parca reddedilir. Kullanici kayitlari tarayicidadir, dokunulmaz.
param(
    [string]$Kaynak = '',
    [string]$KurulumYeri = (Join-Path $env:USERPROFILE '.vsrm-assistant\uygulama'),
    [string[]]$Bilesen = @(),
    [switch]$Kontrol,
    [switch]$Onayli
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$utf8 = New-Object System.Text.UTF8Encoding($false)
$KurulumYeri = [IO.Path]::GetFullPath($KurulumYeri).TrimEnd('\')
$durumYolu = Join-Path (Split-Path -Parent $KurulumYeri) 'kurulu-surum.json'
$surumKok = Join-Path $KurulumYeri 'surumler'
$ortakKok = Join-Path $KurulumYeri 'ortak'
$aktifYol = Join-Path $KurulumYeri 'aktif.txt'
$oncekiYol = Join-Path $KurulumYeri 'onceki.txt'
$bilgiAdi = 'surum-bilgi.json'
$duzenAdlari = @('surumler', 'ortak', 'aktif.txt', 'onceki.txt', '.kilit')
$gecici = Join-Path $surumKok ".gecici-$PID"

function Bul-Kaynak {
    if ($Kaynak) { return $Kaynak }
    $adaylar = Get-ChildItem $env:USERPROFILE -Directory -Filter 'OneDrive*' -ErrorAction SilentlyContinue |
        ForEach-Object { Join-Path $_.FullName 'vsrm-assistant-v3' } |
        Where-Object { Test-Path (Join-Path $_ 'surum.json') }
    if (-not $adaylar) { throw 'Kurulum klasoru bulunamadi. Paylasilan vsrm-assistant-v3 klasorunu OneDrive''a ekle.' }
    return @($adaylar)[0]
}
function Oku-Json([string]$Yol) { [IO.File]::ReadAllText($Yol, $utf8) | ConvertFrom-Json }
function Ozet([string]$Yol) { (Get-FileHash -LiteralPath $Yol -Algorithm SHA256).Hash.ToLower() }
function Dilimler($Parca) { if ($Parca.dilimler) { @($Parca.dilimler) } }
function Gecerli-Ad([string]$Ad) { return ($Ad -match '^[A-Za-z0-9][A-Za-z0-9._-]*$' -and -not $Ad.EndsWith('.')) }
function Guvenli-Ad([string]$Ad) { if (-not (Gecerli-Ad $Ad)) { throw "Gecersiz ad: $Ad" } }
function Hedef-Coz([string]$Kok, [string]$Hedef) {
    # Kurulum klasoru disina cikma denetimi: hedef her zaman verilen kokun icinde kalmali.
    $k = [IO.Path]::GetFullPath($Kok).TrimEnd('\')
    $t = [IO.Path]::GetFullPath((Join-Path $k $Hedef)).TrimEnd('\')
    if ($t -ne $k -and -not $t.StartsWith($k + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Gecersiz hedef: $Hedef" }
    return $t
}
function Ortak-Yol($Parca) { Join-Path $ortakKok ("{0}-{1}" -f $Parca.ad, $Parca.sha256.Substring(0, 12)) }
function Oku-Surumadi([string]$Yol) {
    if (-not (Test-Path -LiteralPath $Yol)) { return '' }
    $ad = ([IO.File]::ReadAllText($Yol, $utf8)).Trim()
    if (-not (Gecerli-Ad $ad)) { return '' }
    if (-not (Test-Path -LiteralPath (Join-Path $surumKok $ad) -PathType Container)) { return '' }
    return $ad
}
function Atomik-Yaz([string]$Yol, [string]$Metin) {
    $tmp = "$Yol.yeni-$PID"
    $b = $utf8.GetBytes($Metin)
    $f = New-Object IO.FileStream($tmp, [IO.FileMode]::Create, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try { $f.Write($b, 0, $b.Length); $f.Flush($true) } finally { $f.Close() }
    if (Test-Path -LiteralPath $Yol) { [IO.File]::Replace($tmp, $Yol, [NullString]::Value) } else { [IO.File]::Move($tmp, $Yol) }
}
function Sil-Oge($Oge) {
    # Junction yalniz baglanti olarak kaldirilir; hedefindeki ortak dosyalara inilmez.
    if (-not $Oge.PSIsContainer) { [IO.File]::SetAttributes($Oge.FullName, [IO.FileAttributes]::Normal); [IO.File]::Delete($Oge.FullName); return }
    if ($Oge.Attributes -band [IO.FileAttributes]::ReparsePoint) { [IO.Directory]::Delete($Oge.FullName); return }
    foreach ($c in @(Get-ChildItem -LiteralPath $Oge.FullName -Force)) { Sil-Oge $c }
    [IO.Directory]::Delete($Oge.FullName)
}
function Sil-Agac([string]$Yol) { Sil-Oge (Get-Item -LiteralPath $Yol -Force) }
function Yeni-Atla { return ,(New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)) }
function Kopyala-Agac([string]$Kaynak, [string]$Hedef, $Atla, [string]$Goreli = '') {
    New-Item -ItemType Directory -Force -Path $Hedef | Out-Null
    foreach ($c in @(Get-ChildItem -LiteralPath $Kaynak -Force)) {
        $g = if ($Goreli) { "$Goreli\$($c.Name)" } else { $c.Name }
        if ($Atla -and $Atla.Contains($g)) { continue }
        if ($c.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
        $t = Join-Path $Hedef $c.Name
        if ($c.PSIsContainer) { Kopyala-Agac $c.FullName $t $Atla $g }
        else { Copy-Item -LiteralPath $c.FullName -Destination $t -Force }
    }
}
# Yeni acilan program dosyalarini virus taramasi kisa sure kilitleyebilir; tasima birkac kez denenir,
# olmazsa kopyalanir. Kopya once gecici adla tamamlanir, yarim klasor kurulu sanilmaz.
function Klasor-Tasi([string]$Kaynak, [string]$Hedef) {
    for ($i = 1; $i -le 8; $i++) {
        try { [IO.Directory]::Move($Kaynak, $Hedef); return }
        catch { Start-Sleep -Milliseconds (400 * $i) }
    }
    $ara = "$Hedef.kopya"
    if (Test-Path -LiteralPath $ara) { Sil-Agac $ara }
    Kopyala-Agac $Kaynak $ara $null
    for ($i = 1; $i -le 8; $i++) {
        try { [IO.Directory]::Move($ara, $Hedef); return }
        catch { if ($i -eq 8) { throw "Klasor tasinamadi: $Hedef. Virus taramasi bitince ayni komutu yeniden calistir." }; Start-Sleep -Milliseconds (400 * $i) }
    }
}
function Baglanti-Kur([string]$Yol, [string]$Hedef) {
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Yol) | Out-Null
    if (Test-Path -LiteralPath $Yol) { Sil-Agac $Yol }
    New-Item -ItemType Junction -Path $Yol -Target $Hedef | Out-Null
}
function Hazirla-Zip($Parca) {
    # Dogrulanmis ZIP yolunu verir. Dilimli parcada dilimler denetlenir, gecici klasorde birlestirilir, tum ozet denetlenir.
    $dosya = Join-Path $kaynak $Parca.dosya
    $dilimler = @(Dilimler $Parca)
    if (Test-Path -LiteralPath $dosya) {
        if ((Ozet $dosya) -eq $Parca.sha256) { return $dosya }
        if (-not $dilimler.Count) { throw "Parca bozuk: $($Parca.dosya). Hicbir sey degismedi." }
    } elseif (-not $dilimler.Count) { throw "Parca yok: $($Parca.dosya). OneDrive esitlemesini bekle." }
    foreach ($d in $dilimler) {
        Guvenli-Ad $d.dosya
        $yol = Join-Path $kaynak $d.dosya
        if (-not (Test-Path -LiteralPath $yol)) { throw "Dilim yok: $($d.dosya). OneDrive esitlemesini bekle." }
        if ((Get-Item -LiteralPath $yol).Length -ne [long]$d.bayt -or (Ozet $yol) -ne $d.sha256) { throw "Dilim bozuk: $($d.dosya). Hicbir sey degismedi." }
    }
    $birlesik = Join-Path $gecici $Parca.dosya
    $cikis = New-Object IO.FileStream($birlesik, [IO.FileMode]::Create, [IO.FileAccess]::Write)
    try {
        foreach ($d in $dilimler) {
            $giris = [IO.File]::OpenRead((Join-Path $kaynak $d.dosya))
            try { $giris.CopyTo($cikis, 1MB) } finally { $giris.Close() }
        }
    } finally { $cikis.Close() }
    if ((Ozet $birlesik) -ne $Parca.sha256) { throw "Birlesik parca bozuk: $($Parca.dosya). Hicbir sey degismedi." }
    return $birlesik
}
function Yeni-Surum-Adi([string]$Surum) {
    # Ayni surum yeniden kurulursa (parca ekleme, yeniden yayin) etkin klasorun ustune yazilmaz: <surum>-r2, -r3...
    $desen = '^' + [regex]::Escape($Surum) + '(-r(\d+))?$'
    $enBuyuk = 0
    foreach ($d in @(Get-ChildItem -LiteralPath $surumKok -Directory -Force)) {
        $m = [regex]::Match($d.Name, $desen)
        if ($m.Success) {
            $n = if ($m.Groups[2].Success) { [int]$m.Groups[2].Value } else { 1 }
            if ($n -gt $enBuyuk) { $enBuyuk = $n }
        }
    }
    if (-not $enBuyuk) { return $Surum }
    return "$Surum-r$($enBuyuk + 1)"
}
function Temizle {
    # Etkin ve bir onceki surum kalir. Silinemeyen (ornegin calisan) klasor sonraki guncellemede yeniden denenir.
    $koru = @(@((Oku-Surumadi $aktifYol), (Oku-Surumadi $oncekiYol)) | Where-Object { $_ } | Sort-Object -Unique)
    foreach ($d in @(Get-ChildItem -LiteralPath $surumKok -Directory -Force)) {
        if ($d.Name.StartsWith('.') -or $koru -contains $d.Name) { continue }
        try { Sil-Oge $d } catch { " uyari: eski surum silinemedi: $($d.Name)" }
    }
    # Ortak klasorler yalniz her korunan surumun kaydi okunabiliyorsa temizlenir.
    $gerekli = Yeni-Atla
    foreach ($ad in $koru) {
        $yol = Join-Path (Join-Path $surumKok $ad) $bilgiAdi
        if (-not (Test-Path -LiteralPath $yol)) { return }
        foreach ($p in @((Oku-Json $yol).parcalar)) {
            if ($p.hedef -ne '.') { [void]$gerekli.Add((Split-Path -Leaf (Ortak-Yol $p))) }
        }
    }
    if (-not (Test-Path -LiteralPath $ortakKok)) { return }
    foreach ($d in @(Get-ChildItem -LiteralPath $ortakKok -Directory -Force)) {
        if ($gerekli.Contains($d.Name)) { continue }
        try { Sil-Oge $d } catch { " uyari: ortak klasor silinemedi: $($d.Name)" }
    }
}

$kaynak = Bul-Kaynak
$liste = Oku-Json (Join-Path $kaynak 'surum.json')
Guvenli-Ad $liste.surum
$kurulu = @{}
$secili = @($Bilesen | ForEach-Object { $_ -split ',' } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
$ilkKurulum = $true
$eskiDuz = $false
$eskiSurum = ''
$aktifAd = Oku-Surumadi $aktifYol
$aktifBilgi = $null
if ($aktifAd) {
    $bilgiYol = Join-Path (Join-Path $surumKok $aktifAd) $bilgiAdi
    if (Test-Path -LiteralPath $bilgiYol) { $aktifBilgi = Oku-Json $bilgiYol }
}
if ($aktifBilgi) {
    $ilkKurulum = $false
    foreach ($p in @($aktifBilgi.parcalar)) { $kurulu[$p.ad] = $p.sha256 }
    $secili = @($secili + @($aktifBilgi.bilesenler) | Where-Object { $_ } | Sort-Object -Unique)
} elseif (Test-Path $durumYolu) {
    # Surum klasorlerinden onceki duz kurulum: kok klasore acilmis parcalar.
    $ilkKurulum = $false
    $durum = Oku-Json $durumYolu
    foreach ($p in $durum.parcalar) { $kurulu[$p.ad] = $p.sha256 }
    $secili = @($secili + @($durum.bilesenler) | Where-Object { $_ } | Sort-Object -Unique)
    $eskiDuz = -not $aktifAd
    $eskiSurum = [string]$durum.surum
}

# Kayitta olup diskte bulunmayan parca yeniden kurulur.
foreach ($p in @($liste.parcalar)) {
    if (-not $kurulu.ContainsKey($p.ad) -or $kurulu[$p.ad] -ne $p.sha256) { continue }
    if ($p.hedef -eq '.') {
        if ($eskiDuz -and -not @(Get-ChildItem -LiteralPath $KurulumYeri -Force -ErrorAction SilentlyContinue | Where-Object { $duzenAdlari -notcontains $_.Name }).Count) { $kurulu.Remove($p.ad) }
    } elseif (-not (Test-Path -LiteralPath (Ortak-Yol $p)) -and -not ($eskiDuz -and (Test-Path -LiteralPath (Hedef-Coz $KurulumYeri $p.hedef)))) {
        $kurulu.Remove($p.ad)
    }
}

$bekleyen = @($liste.parcalar | Where-Object {
    $_.ad -ne 'danisman-paketi' -and $kurulu[$_.ad] -ne $_.sha256 -and
    ((-not $secili.Count -and $ilkKurulum) -or -not $_.bilesen -or $secili -contains $_.bilesen)
})

if (-not $bekleyen.Count) { "Guncel. Surum: $($liste.surum)"; exit 0 }
$toplam = ($bekleyen | Measure-Object -Property bayt -Sum).Sum
"Yeni surum: $($liste.surum). Guncellenecek parca: $($bekleyen.Count), boyut: {0:N0} MB" -f ($toplam / 1MB)
$bekleyen | ForEach-Object { " - $($_.ad)" }
if ($Kontrol) { exit 10 }
if (-not $Onayli) {
    if ((Read-Host 'Devam edilsin mi? (E/H)') -notmatch '^[eE]') { 'Iptal edildi. Hicbir sey degismedi.'; exit 0 }
}

New-Item -ItemType Directory -Force -Path $surumKok, $ortakKok | Out-Null
try { $kilit = [IO.File]::Open((Join-Path $KurulumYeri '.kilit'), [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None) }
catch { throw 'Baska bir kurulum suruyor.' }
try {
    foreach ($d in @(Get-ChildItem -LiteralPath $surumKok -Directory -Force -Filter '.gecici-*')) { Sil-Oge $d }
    New-Item -ItemType Directory -Force -Path $gecici | Out-Null
    $yeni = Join-Path $gecici 'yeni'
    $bekleyenAdlar = @($bekleyen | ForEach-Object { $_.ad })
    $kurulacak = @($liste.parcalar | Where-Object {
        $_.ad -ne 'danisman-paketi' -and ($bekleyenAdlar -contains $_.ad -or $kurulu[$_.ad] -eq $_.sha256)
    })

    # Once hepsi dogrulanir; bozuk bir parca veya gecersiz hedef varsa hicbir sey degismez.
    foreach ($p in $kurulacak) { Guvenli-Ad $p.ad; [void](Hedef-Coz $yeni $p.hedef) }
    $ziplar = @{}
    foreach ($p in $bekleyen) { Guvenli-Ad $p.dosya; $ziplar[$p.ad] = Hazirla-Zip $p }

    $agirlar = @($kurulacak | Where-Object { $_.hedef -ne '.' })
    if ($eskiDuz) {
        # Duz kurulumdaki degismemis agir parcalar kopyalanmadan ortak klasore tasinir.
        foreach ($p in ($agirlar | Where-Object { $kurulu[$_.ad] -eq $_.sha256 })) {
            $ortakYol = Ortak-Yol $p
            $eskiYol = Hedef-Coz $KurulumYeri $p.hedef
            if ((Test-Path -LiteralPath $ortakYol) -or -not (Test-Path -LiteralPath $eskiYol)) { continue }
            if ((Get-Item -LiteralPath $eskiYol -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
            [IO.Directory]::Move($eskiYol, $ortakYol)
            Baglanti-Kur $eskiYol $ortakYol
        }
    }

    # Uygulama koku: etkin surumdeki dosyalar (yerel ciktilar dahil) alinir, degisen parca ustune acilir.
    $kokParcalar = @($bekleyen | Where-Object { $_.hedef -eq '.' })
    $kokDosyalari = @(if ($aktifBilgi) { $aktifBilgi.kok_dosyalari })
    $atla = Yeni-Atla
    foreach ($a in @($duzenAdlari + $bilgiAdi)) { [void]$atla.Add($a) }
    foreach ($p in $agirlar) { [void]$atla.Add(($p.hedef -replace '/', '\').Trim('\')) }
    if ($kokParcalar.Count) { foreach ($f in $kokDosyalari) { if ($f) { [void]$atla.Add($f) } } }
    $kokKaynak = if ($aktifAd) { Join-Path $surumKok $aktifAd } elseif ($eskiDuz) { $KurulumYeri } else { '' }
    if ($kokKaynak) { Kopyala-Agac $kokKaynak $yeni $atla } else { New-Item -ItemType Directory -Force -Path $yeni | Out-Null }
    if ($kokParcalar.Count) { $kokDosyalari = @() }
    foreach ($p in $kokParcalar) {
        $acik = Join-Path $gecici "kok-$($p.ad)"
        [IO.Compression.ZipFile]::ExtractToDirectory($ziplar[$p.ad], $acik)
        $kokDosyalari += @(Get-ChildItem -LiteralPath $acik -Recurse -File -Force | ForEach-Object { $_.FullName.Substring($acik.Length + 1) })
        Kopyala-Agac $acik $yeni $null
        " kuruldu: $($p.ad)"
    }

    # Agir parcalar ozetine gore ortakta durur; ayni ozet yeniden acilmaz.
    foreach ($p in $agirlar) {
        $ortakYol = Ortak-Yol $p
        if ($bekleyenAdlar -contains $p.ad) {
            if (-not (Test-Path -LiteralPath $ortakYol)) {
                $acik = Join-Path $gecici "agir-$($p.ad)"
                [IO.Compression.ZipFile]::ExtractToDirectory($ziplar[$p.ad], $acik)
                Klasor-Tasi $acik $ortakYol
            }
            " kuruldu: $($p.ad)"
        }
        Baglanti-Kur (Hedef-Coz $yeni $p.hedef) $ortakYol
    }

    $bilesenler = @($kurulacak | ForEach-Object { $_.bilesen } | Where-Object { $_ } | Sort-Object -Unique)
    $parcaKaydi = @($kurulacak | ForEach-Object { @{ ad = $_.ad; sha256 = $_.sha256; hedef = $_.hedef; bilesen = $_.bilesen } })
    $bilgi = @{ surum = $liste.surum; bilesenler = @($bilesenler); kok_dosyalari = @($kokDosyalari); parcalar = @($parcaKaydi) }
    [IO.File]::WriteAllText((Join-Path $yeni $bilgiAdi), ($bilgi | ConvertTo-Json -Depth 4), $utf8)

    # Yeni surum yerine alinir ve etkinlestirilir. aktif.txt degisene kadar eski surum etkindir.
    $yeniAd = Yeni-Surum-Adi $liste.surum
    [IO.Directory]::Move($yeni, (Join-Path $surumKok $yeniAd))
    if ($aktifAd) { Atomik-Yaz $oncekiYol $aktifAd }
    Atomik-Yaz $aktifYol $yeniAd

    # Bundan sonrasi temizliktir; hata yeni surumu geri almaz.
    $kayit = @{ surum = $liste.surum; bilesenler = @($bilesenler); parcalar = @($kurulacak | ForEach-Object { @{ ad = $_.ad; sha256 = $_.sha256 } }) }
    try { Atomik-Yaz $durumYolu ($kayit | ConvertTo-Json -Depth 4) } catch { " uyari: kurulum kaydi yazilamadi." }
    if ($eskiDuz) {
        # Duz kurulum bir onceki surum olarak surumler altina tasinir.
        try {
            $eskiKlasor = Yeni-Surum-Adi $(if (Gecerli-Ad $eskiSurum) { $eskiSurum } else { 'eski-duzen' })
            $eskiYer = Join-Path $surumKok $eskiKlasor
            New-Item -ItemType Directory -Force -Path $eskiYer | Out-Null
            foreach ($c in @(Get-ChildItem -LiteralPath $KurulumYeri -Force | Where-Object { $duzenAdlari -notcontains $_.Name })) {
                Move-Item -LiteralPath $c.FullName -Destination (Join-Path $eskiYer $c.Name)
            }
            $eskiParcalar = @($agirlar | Where-Object { $kurulu[$_.ad] -eq $_.sha256 } | ForEach-Object { @{ ad = $_.ad; sha256 = $_.sha256; hedef = $_.hedef; bilesen = $_.bilesen } })
            [IO.File]::WriteAllText((Join-Path $eskiYer $bilgiAdi), (@{ surum = $eskiSurum; bilesenler = @(); kok_dosyalari = @(); parcalar = @($eskiParcalar) } | ConvertTo-Json -Depth 4), $utf8)
            Atomik-Yaz $oncekiYol $eskiKlasor
        } catch { " uyari: eski duzen tasinamadi: $($_.Exception.Message)" }
    }
    try { Temizle } catch { " uyari: temizlik tamamlanamadi: $($_.Exception.Message)" }
    "Tamamlandi. Surum: $($liste.surum). Etkin klasor: $yeniAd"
}
finally {
    if (Test-Path -LiteralPath $gecici) { try { Sil-Agac $gecici } catch { } }
    $kilit.Close()
}

@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Uygulama-Kur.ps1"
echo.
pause

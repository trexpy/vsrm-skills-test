# vSRM kurulumunun tek giris noktasi. Yapay zeka arayuzu veya danisman calistirir.
# -Liste secenekleri JSON verir. -Bilesen ile secilen parcalar kurulur; ayni komut sonradan yenisini ekler.
param(
    [string]$Kaynak = '',
    [string[]]$Bilesen = @(),
    [string[]]$Komut = @(),
    [string]$HomeDir = $env:USERPROFILE,
    [string]$PaketYeri = (Join-Path $env:USERPROFILE '.vsrm-assistant\paket'),
    [string]$KurulumYeri = (Join-Path $env:USERPROFILE '.vsrm-assistant\uygulama'),
    [switch]$Liste
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Add-Type -AssemblyName System.IO.Compression.FileSystem
$utf8 = New-Object System.Text.UTF8Encoding($false)

function Bul-Kaynak {
    if ($Kaynak) { return $Kaynak }
    $adaylar = Get-ChildItem $HomeDir -Directory -Filter 'OneDrive*' -ErrorAction SilentlyContinue |
        ForEach-Object { Join-Path $_.FullName 'vsrm-assistant-v3' } |
        Where-Object { Test-Path (Join-Path $_ 'surum.json') }
    if (-not $adaylar) { throw 'Kurulum klasoru bulunamadi. Paylasilan vsrm-assistant-v3 klasorunu OneDrive''a ekle.' }
    return @($adaylar)[0]
}
function Dogrula($Parca, [string]$Yer) {
    $dosya = Join-Path $Yer $Parca.dosya
    if (-not (Test-Path -LiteralPath $dosya)) { throw "Parca yok: $($Parca.dosya). OneDrive esitlemesini bekle." }
    if ((Get-FileHash -LiteralPath $dosya -Algorithm SHA256).Hash.ToLower() -ne $Parca.sha256) { throw "Parca bozuk: $($Parca.dosya)" }
    return $dosya
}

$kaynak = Bul-Kaynak
$manifest = [IO.File]::ReadAllText((Join-Path $kaynak 'surum.json'), $utf8) | ConvertFrom-Json
$paket = $manifest.parcalar | Where-Object { $_.ad -eq 'danisman-paketi' } | Select-Object -First 1
if (-not $paket) { throw 'Surum listesinde danisman paketi yok.' }

# Paket ayni surumdeyse yeniden acilmaz.
$isaret = Join-Path $PaketYeri '.surum'
$kok = Join-Path $PaketYeri 'vsrm-assistant'
if (-not (Test-Path $isaret) -or ([IO.File]::ReadAllText($isaret, $utf8)).Trim() -ne $paket.sha256) {
    $zip = Dogrula $paket $kaynak
    $gecici = "$PaketYeri.yeni-$PID"
    if (Test-Path $gecici) { Remove-Item $gecici -Recurse -Force }
    [IO.Compression.ZipFile]::ExtractToDirectory($zip, $gecici)
    if (Test-Path $PaketYeri) { Remove-Item $PaketYeri -Recurse -Force }
    Move-Item $gecici $PaketYeri
    [IO.File]::WriteAllText($isaret, $paket.sha256, $utf8)
}
$kurBetik = Join-Path $kok 'kurulum\Kur.ps1'
$uygBetik = Join-Path $kok 'kurulum\Uygulama-Kur.ps1'

$bilesenler = @{}
foreach ($p in $manifest.parcalar) {
    if ($p.ad -eq 'danisman-paketi' -or -not $p.bilesen) { continue }
    $bilesenler[$p.bilesen] = [long]$bilesenler[$p.bilesen] + [long]$p.bayt
}
$tanim = @{ uygulama = 'Danisman Merkezi ekranlari'; ses = 'Toplanti kaydini yaziya dokme (ses modeli)' }

if ($Liste) {
    $komutListesi = & $kurBetik -HomeDir $HomeDir -Liste | Out-String | ConvertFrom-Json
    [pscustomobject]@{
        surum = $manifest.surum
        komutlar = @($komutListesi)
        bilesenler = @($bilesenler.Keys | Sort-Object | ForEach-Object {
            [pscustomobject]@{ ad = $_; ozet = $tanim[$_]; boyut_mb = [math]::Ceiling($bilesenler[$_] / 1MB) }
        })
    } | ConvertTo-Json -Depth 4
    return
}

$secilen = @($Bilesen | ForEach-Object { $_ -split ',' } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
$yanlis = @($secilen | Where-Object { -not $bilesenler.ContainsKey($_) })
if ($yanlis.Count) { throw "Bilinmeyen bilesen: $($yanlis -join ', ')" }

$kurArg = @{ HomeDir = $HomeDir }
if ($Komut.Count) { $kurArg.Secim = $Komut }
& $kurBetik @kurArg
# Bilesen verilmeyen cagri guncellemedir: kurulu parcalar varsa yeni surume gecer. Yalniz komut eklemek parcalara dokunmaz.
$durumYolu = Join-Path (Split-Path -Parent $KurulumYeri) 'kurulu-surum.json'
if ($secilen.Count -or (-not $Komut.Count -and (Test-Path $durumYolu))) {
    $uygArg = @{ Kaynak = $kaynak; KurulumYeri = $KurulumYeri; Onayli = $true }
    if ($secilen.Count) { $uygArg.Bilesen = $secilen -join ',' }
    & $uygBetik @uygArg
    if ($LASTEXITCODE) { throw 'Uygulama parcalari kurulamadi.' }
}
'Tamam.'

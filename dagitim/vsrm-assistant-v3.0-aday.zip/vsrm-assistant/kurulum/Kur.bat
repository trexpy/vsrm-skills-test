@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Kur.ps1"
echo.
echo Pencereyi kapatabilirsin. Claude, Codex veya Gemini acikse yeniden baslat.
pause

# vSRM komutlarini Claude, Codex, Gemini CLI ve Antigravity icin kullanici duzeyinde kurar.
# -Secim verilmezse hepsi kurulur. Secim eklemelidir: onceki komutlar korunur, yeniden calistirmak gunceller.
param(
    [string]$HomeDir = $env:USERPROFILE,
    [string[]]$Secim = @(),
    [switch]$Liste,
    [switch]$Kaldir
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$repo = Split-Path -Parent $PSScriptRoot
$utf8 = New-Object System.Text.UTF8Encoding($false)
$komutlar = ([IO.File]::ReadAllText((Join-Path $PSScriptRoot 'komutlar.json'), $utf8) | ConvertFrom-Json).komutlar
$surum = ([regex]::Match([IO.File]::ReadAllText((Join-Path $repo 'SURUM.txt'), $utf8), '(?m)^S.r.m:\s*(\S+)')).Groups[1].Value
$hedefler = @(
    (Join-Path $HomeDir '.claude\skills'),
    (Join-Path $HomeDir '.agents\skills'),
    (Join-Path $HomeDir '.gemini\skills'),
    (Join-Path $HomeDir '.gemini\config\skills')
)
$geminiKomut = Join-Path $HomeDir '.gemini\commands'
$kayit = Join-Path $HomeDir '.vsrm-assistant\kurulum.json'
$zorunlu = @($komutlar | Where-Object { $_.zorunlu } | ForEach-Object { $_.ad })

function Yaz([string]$Yol, [string]$Metin) {
    New-Item -ItemType Directory -Force (Split-Path -Parent $Yol) | Out-Null
    [IO.File]::WriteAllText($Yol, ($Metin -replace "`r`n", "`n"), $utf8)
}
function Dosyalar($Desen) {
    if ($Desen -in 'kurallar', 'sablonlar', 'musteri-formu.md') {
        return Get-ChildItem (Join-Path $repo $Desen) -Recurse -File | ForEach-Object {
            @{ Kaynak = $_.FullName; Hedef = $_.FullName.Substring($repo.Length + 1) }
        }
    }
    $taban = Join-Path $repo 'skills\vsrm'
    return Get-ChildItem (Join-Path $taban $Desen) -File | ForEach-Object {
        @{ Kaynak = $_.FullName; Hedef = $_.FullName.Substring($taban.Length + 1) }
    }
}
function Oku-Kayit {
    if (Test-Path $kayit) { return [IO.File]::ReadAllText($kayit, $utf8) | ConvertFrom-Json }
    return $null
}
function Temizle($Eski) {
    if (-not $Eski) { return }
    foreach ($yol in $Eski.yollar) { if (Test-Path -LiteralPath $yol) { Remove-Item -LiteralPath $yol -Recurse -Force } }
    Remove-Item $kayit -Force
}

$eski = Oku-Kayit
$kurulu = @(if ($eski -and $eski.komutlar) { $eski.komutlar })
$istenen = @($Secim | ForEach-Object { $_ -split ',' } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
$bilinmeyen = @($istenen | Where-Object { $komutlar.ad -notcontains $_ })
if ($bilinmeyen.Count) { throw "Bilinmeyen komut: $($bilinmeyen -join ', ')" }

if ($Liste) {
    $komutlar | ForEach-Object {
        [pscustomobject]@{ ad = $_.ad; ozet = $_.ozet; zorunlu = [bool]$_.zorunlu; kurulu = ($kurulu -contains $_.ad) }
    } | ConvertTo-Json -Depth 3
    return
}
if ($Kaldir -and -not $istenen.Count) { Temizle $eski; 'vSRM komutlari kaldirildi.'; return }

if ($Kaldir) {
    $kurulacak = @($kurulu | Where-Object { $istenen -notcontains $_ })
    if (@($istenen | Where-Object { $zorunlu -contains $_ }).Count) { throw 'Zorunlu komut tek basina kaldirilamaz.' }
} elseif ($istenen.Count) {
    $kurulacak = @($kurulu + $istenen + $zorunlu | Sort-Object -Unique)
} elseif ($kurulu.Count) {
    $kurulacak = $kurulu
} else {
    $kurulacak = @($komutlar | ForEach-Object { $_.ad })
}
Temizle $eski

$ortak = [IO.File]::ReadAllText((Join-Path $repo 'skills\vsrm\ortak-kurallar.md'), $utf8)
$yonlendirme = [IO.File]::ReadAllText((Join-Path $repo 'skills\vsrm\yonlendirme.md'), $utf8)
$yollar = New-Object System.Collections.ArrayList
foreach ($k in ($komutlar | Where-Object { $kurulacak -contains $_.ad })) {
    $aciklama = $k.aciklama -replace '"', "'"
    $govde = "---`nname: $($k.ad)`ndescription: `"$aciklama`"`n---`n`n# $($k.ad)`n`nKarsindaki kisi cogunlukla teknik olmayan bir ITG danismanidir. Kisa ve Turkce konus. Ise baslamadan once ortak-kurallar.md dosyasini oku.`n`n$($k.adim)`n"
    if ($k.yonlendirici) { $govde += "`n$yonlendirme" }
    foreach ($hedef in $hedefler) {
        $kok = Join-Path $hedef $k.ad
        [void]$yollar.Add($kok)
        Yaz (Join-Path $kok 'SKILL.md') $govde
        Yaz (Join-Path $kok 'ortak-kurallar.md') $ortak
        foreach ($desen in $k.dosyalar) {
            foreach ($d in Dosyalar $desen) {
                $yeni = Join-Path $kok $d.Hedef
                New-Item -ItemType Directory -Force (Split-Path -Parent $yeni) | Out-Null
                Copy-Item -LiteralPath $d.Kaynak -Destination $yeni -Force
            }
        }
    }
    $toml = Join-Path $geminiKomut "$($k.ad).toml"
    [void]$yollar.Add($toml)
    Yaz $toml "description = `"$aciklama`"`nprompt = `"`"`"$($k.ad) skill'ini etkinlestir ve talimatlarini uygula. Istek: {{args}}`"`"`"`n"
}
Yaz $kayit ((@{ surum = $surum; komutlar = @($kurulacak); yollar = @($yollar) } | ConvertTo-Json -Depth 3))
"vSRM komutlari kuruldu. Surum: $surum, komut: $($kurulacak.Count)"

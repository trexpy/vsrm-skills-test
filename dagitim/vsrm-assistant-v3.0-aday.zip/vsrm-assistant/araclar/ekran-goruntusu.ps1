﻿# Bir HTML ekraninin PNG goruntusunu Edge ile alir. Referansla yan yana karsilastirmak icindir.
# Kullanim: powershell -ExecutionPolicy Bypass -File araclar\ekran-goruntusu.ps1 -Html cikti\ekran.html
param(
    [Parameter(Mandatory = $true)][string]$Html,
    [string]$Png
)
$edge = @(
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $edge) { Write-Error 'Microsoft Edge bulunamadi.'; exit 2 }

$path = (Resolve-Path $Html).Path
if (-not $Png) { $Png = [IO.Path]::ChangeExtension($path, '.png') }
$profile = Join-Path $env:TEMP "vsrm-ekran-$PID"
$url = 'file:///' + ($path -replace '\\', '/')
$a = @('--headless=new', '--disable-gpu', '--hide-scrollbars', '--window-size=1570,1040', "--user-data-dir=$profile", "--screenshot=$Png", '--virtual-time-budget=6000', $url)
Start-Process -FilePath $edge -ArgumentList $a -Wait -NoNewWindow -RedirectStandardError (Join-Path $env:TEMP "vsrm-ekran-$PID.txt")
Remove-Item $profile -Recurse -Force -ErrorAction SilentlyContinue
if (Test-Path $Png) { "Goruntu: $Png" } else { Write-Error 'Goruntu alinamadi.'; exit 1 }
